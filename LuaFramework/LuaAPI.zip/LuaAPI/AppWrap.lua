---@class App : GameCore.UnitySingleton
---@field ResMgr GameLogic.ResourcesManager
---@field AssetBundleMgr ResMgr.AssetBundleManager
---@field BuglySdkMgr GameLogic.BuglySdkManager
---@field LuaMgr GameLogic.LuaManager
---@field ObjectPoolMgr GameLogic.ObjectPoolManager
---@field NetWorkMgr GameLogic.NetworkManager
---@field CompressMgr CompressManager
---@field GameMgr GameLogic.GameManager
---@field SoundMgr GameLogic.SoundManager
---@field PhoneMgr GameLogic.PhoneManager
---@field ImageDownloadMgr GameLogic.ImageDownloadManager
---@field SDKMgr GameLogic.SDKManager
---@field WebSocketMgr GameLogic.WebSocketManager
---@field VersionMgr GameLogic.VersionManager
local m = {}
function m:Initialize() end
function m:StartUp() end
function m:InitResMgr() end
function m:ReStart() end
---@param msgID string
---@param data object
function m:CallLuaMessage(msgID, data) end
App = m
return m