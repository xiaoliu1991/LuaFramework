---@class BulletAction : UnityEngine.MonoBehaviour
---@field _timeout float
local m = {}
BulletAction = m
return m