---@class Candlelight.UI.HyperText : UnityEngine.UI.Text
---@field IsSilent bool
---@field ClickedLink Candlelight.UI.HyperText.HyperlinkEvent
---@field DefaultLinkStyle Candlelight.UI.HyperTextStyles.Link
---@field DefaultQuadMaterial UnityEngine.Material
---@field DefaultTextColor UnityEngine.Color
---@field DefaultTextStyle UnityEngine.FontStyle
---@field EnteredLink Candlelight.UI.HyperText.HyperlinkEvent
---@field ExitedLink Candlelight.UI.HyperText.HyperlinkEvent
---@field FontSizeToUse int
---@field FontToUse UnityEngine.Font
---@field InputTextSource Candlelight.ITextSource
---@field Interactable bool
---@field LinkHitboxPadding Candlelight.ImmutableRectOffset
---@field OpenURLPatterns bool
---@field PressedLink Candlelight.UI.HyperText.HyperlinkEvent
---@field QuadMaterial UnityEngine.Material
---@field QuadMaterialForRendering UnityEngine.Material
---@field ReleasedLink Candlelight.UI.HyperText.HyperlinkEvent
---@field ShouldOverrideStylesFontColor bool
---@field ShouldOverrideStylesFontSize bool
---@field ShouldOverrideStylesFontStyle bool
---@field ShouldOverrideStylesLineSpacing bool
---@field ShouldOverrideLinkHitboxPadding bool
---@field Styles Candlelight.UI.HyperTextStyles
---@field UploadedText string
---@field mainTexture UnityEngine.Texture
---@field preferredHeight float
---@field preferredWidth float
---@field pixelsPerUnit float
local m = {}
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerExit(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end
---@overload fun(linkHitboxes:table):void
---@param linkIndex int
---@param hitboxes table
function m:GetLinkHitboxes(linkIndex, hitboxes) end
---@param collections table
function m:GetLinkKeywordCollections(collections) end
---@param links table
---@return int
function m:GetLinks(links) end
---@param collections table
function m:GetQuadKeywordCollections(collections) end
---@param collections table
function m:GetTagKeywordCollections(collections) end
---@param value System.Collections.Generic.IList
function m:SetLinkKeywordCollections(value) end
---@param value System.Collections.Generic.IList
function m:SetQuadKeywordCollections(value) end
---@param value System.Collections.Generic.IList
function m:SetTagKeywordCollections(value) end
---@param pointerPosition UnityEngine.Vector2
---@param eventCamera UnityEngine.Camera
---@return bool
function m:Raycast(pointerPosition, eventCamera) end
function m:SetMaterialDirty() end
function m:SetVerticesDirty() end
---@param clipRect UnityEngine.Rect
---@param validRect bool
function m:Cull(clipRect, validRect) end
---@param clipRect UnityEngine.Rect
---@param validRect bool
function m:SetClipRect(clipRect, validRect) end
---@param baseMaterial UnityEngine.Material
---@return UnityEngine.Material
function m:GetModifiedMaterial(baseMaterial) end
function m:FontTextureChanged() end
---@param extents UnityEngine.Vector2
---@return UnityEngine.TextGenerationSettings
function m:GetGenerationSettings(extents) end
Candlelight = {}
Candlelight.UI = {}
Candlelight.UI.HyperText = m
return m