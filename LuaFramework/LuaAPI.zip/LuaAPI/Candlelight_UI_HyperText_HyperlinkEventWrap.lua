---@class Candlelight.UI.HyperText.HyperlinkEvent : UnityEngine.Events.UnityEvent
local m = {}
Candlelight = {}
Candlelight.UI = {}
Candlelight.UI.HyperText = {}
Candlelight.UI.HyperText.HyperlinkEvent = m
return m