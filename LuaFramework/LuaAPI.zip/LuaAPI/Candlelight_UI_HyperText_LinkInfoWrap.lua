---@class Candlelight.UI.HyperText.LinkInfo
---@field ClassName string
---@field Index int
---@field Name string
local m = {}
Candlelight = {}
Candlelight.UI = {}
Candlelight.UI.HyperText = {}
Candlelight.UI.HyperText.LinkInfo = m
return m