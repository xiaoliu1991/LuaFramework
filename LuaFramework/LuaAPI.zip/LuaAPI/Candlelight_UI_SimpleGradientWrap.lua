---@class Candlelight.UI.SimpleGradient : UnityEngine.UI.BaseMeshEffect
---@field BottomColor UnityEngine.Color32
---@field ColorTintMode Candlelight.UI.ColorTintMode
---@field FillMode Candlelight.UI.SimpleGradient.GradientFillMode
---@field TopColor UnityEngine.Color32
local m = {}
---@param vh UnityEngine.UI.VertexHelper
function m:ModifyMesh(vh) end
Candlelight = {}
Candlelight.UI = {}
Candlelight.UI.SimpleGradient = m
return m