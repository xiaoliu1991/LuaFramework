---@class Candlelight.UI.Typewriter : UnityEngine.MonoBehaviour
---@field Cursor string
---@field CursorBlink float
---@field CharacterDelay float
---@field InputTextSource Candlelight.ITextSource
---@field OnFinish Candlelight.UI.Typewriter.TypewriterEvent
---@field OnTypeCharacter Candlelight.UI.Typewriter.TypewriterCharacterEvent
---@field OutputText string
---@field Progress float
---@field Text string
---@field ShouldUseUnscaledTime bool
local m = {}
Candlelight = {}
Candlelight.UI = {}
Candlelight.UI.Typewriter = m
return m