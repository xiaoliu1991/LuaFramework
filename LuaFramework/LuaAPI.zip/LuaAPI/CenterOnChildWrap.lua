---@class CenterOnChild : UnityEngine.MonoBehaviour
---@field onCenter UnityEngine.Events.UnityAction
local m = {}
---@overload fun(target:UnityEngine.GameObject):void
---@param index int
function m:CenterOn(index) end
function m:LeftMove() end
function m:RightMove() end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnEndDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end
CenterOnChild = m
return m