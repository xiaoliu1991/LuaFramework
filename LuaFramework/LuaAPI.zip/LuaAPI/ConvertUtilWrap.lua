---@class ConvertUtil
local m = {}
---@param fromEncode string
---@return System.Text.Encoding
function m.GetEncoding(fromEncode) end
---@param srcStr string
---@param fromEncode string
---@param toEncode string
---@return string
function m.ConvertEncode(srcStr, fromEncode, toEncode) end
---@param source string
---@return string
function m.String2Unicode(source) end
---@param srcText string
---@return string
function m.UnicodeToString(srcText) end
---@param obj object
---@return string
function m.ObjToString(obj) end
---@param param object
---@return ResUpdate.ResUpdateProgress
function m.ObjToUpdateProgress(param) end
---@param obj object
---@return float
function m.ObjToFloat(obj) end
---@param obj object
---@return int
function m.ObjToInt(obj) end
---@param str string
---@return long
function m.StrToLong(str) end
---@param str string
---@return int
function m.StrToInt(str) end
---@param str string
---@return byte
function m.StrToByte(str) end
---@param str string
---@return short
function m.StrToShort(str) end
---@param str string
---@return float
function m.StrToFloat(str) end
ConvertUtil = m
return m