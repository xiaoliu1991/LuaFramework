---@class DG.Tweening.LoopType : System.Enum
---@field value__ int
---@field Restart DG.Tweening.LoopType
---@field Yoyo DG.Tweening.LoopType
---@field Incremental DG.Tweening.LoopType
local m = {}
DG = {}
DG.Tweening = {}
DG.Tweening.LoopType = m
return m