---@class DG.Tweening.PathMode : System.Enum
---@field value__ int
---@field Ignore DG.Tweening.PathMode
---@field Full3D DG.Tweening.PathMode
---@field TopDown2D DG.Tweening.PathMode
---@field Sidescroller2D DG.Tweening.PathMode
local m = {}
DG = {}
DG.Tweening = {}
DG.Tweening.PathMode = m
return m