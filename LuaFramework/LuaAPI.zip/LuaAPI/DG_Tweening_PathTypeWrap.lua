---@class DG.Tweening.PathType : System.Enum
---@field value__ int
---@field Linear DG.Tweening.PathType
---@field CatmullRom DG.Tweening.PathType
local m = {}
DG = {}
DG.Tweening = {}
DG.Tweening.PathType = m
return m