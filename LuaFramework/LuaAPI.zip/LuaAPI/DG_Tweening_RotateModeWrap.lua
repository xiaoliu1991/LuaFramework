---@class DG.Tweening.RotateMode : System.Enum
---@field value__ int
---@field Fast DG.Tweening.RotateMode
---@field FastBeyond360 DG.Tweening.RotateMode
---@field WorldAxisAdd DG.Tweening.RotateMode
---@field LocalAxisAdd DG.Tweening.RotateMode
local m = {}
DG = {}
DG.Tweening = {}
DG.Tweening.RotateMode = m
return m