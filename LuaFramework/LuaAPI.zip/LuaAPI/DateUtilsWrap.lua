---@class DateUtils : object
---@field DEFAULT_PATTERN string
local m = {}
---@param millis long
---@param format string
---@return string
function m.Millis2String(millis, format) end
---@overload fun(time:string, pattern:string):long
---@param time string
---@return long
function m.String2Millis(time) end
---@param timeType string
---@param time string
---@param isUtc bool
---@return string
function m.GetDateInfo(timeType, time, isUtc) end
---@overload fun(time:string, format:string):string
---@param ticks long
---@param format string
---@return string
function m:DateTimeFormat(ticks, format) end
---@param dateTime1 string
---@param dateTime2 string
---@return int
function m:DateTimeCompareTo(dateTime1, dateTime2) end
---@param beginTime string
---@param endTime string
---@param spanType string
---@param isUtc bool
---@return double
function m.GetTimeDoubleInfo(beginTime, endTime, spanType, isUtc) end
---@param beginTime string
---@param endTime string
---@param spanType string
---@param isUtc bool
---@return long
function m.GetTimeIntInfo(beginTime, endTime, spanType, isUtc) end
---@param year int
---@return bool
function m.IsLeapYear(year) end
---@param time string
---@return int
function m:GetWeekOfMonth(time) end
---@overload fun(time:string, pattern:string):string
---@param time string
---@return string
function m.getChineseZodiac(time) end
---@overload fun(millis:long):string
---@overload fun(month:int, day:int):string
---@param time string
---@param pattern string
---@return string
function m.getZodiac(time, pattern) end
DateUtils = m
return m