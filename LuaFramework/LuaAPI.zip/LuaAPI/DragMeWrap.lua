---@class DragMe : UnityEngine.MonoBehaviour
---@field dragOnSurfaces bool
local m = {}
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnBeginDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnEndDrag(eventData) end
---@param canDragAction System.Func
function m:SetCanDragFunc(canDragAction) end
DragMe = m
return m