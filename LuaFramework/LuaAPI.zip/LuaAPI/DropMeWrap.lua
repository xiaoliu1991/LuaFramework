---@class DropMe : UnityEngine.MonoBehaviour
---@field containerImage UnityEngine.UI.Image
---@field receivingImage UnityEngine.UI.Image
---@field highlightColor UnityEngine.Color
local m = {}
function m:OnEnable() end
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnDrop(data) end
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnPointerEnter(data) end
---@param data UnityEngine.EventSystems.PointerEventData
function m:OnPointerExit(data) end
---@param acion System.Action
function m:SetDropAction(acion) end
---@param acion System.Action
function m:SetEnterAction(acion) end
---@param data UnityEngine.EventSystems.PointerEventData
function m:DoDropAction(data) end
DropMe = m
return m