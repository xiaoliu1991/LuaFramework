---@class FishAction : UnityEngine.MonoBehaviour
---@field PathList table
---@field PathToWorldList table
---@field PathingList table
---@field CurtargetPoint int
---@field LastPos UnityEngine.Vector2
---@field CurtargetPos UnityEngine.Vector2
---@field curAngle float
---@field nextAngle float
---@field rotateTime float
---@field TestFish UnityEngine.Transform
---@field V3 table
---@field _fishPathType FishPathType
local m = {}
FishAction = m
return m