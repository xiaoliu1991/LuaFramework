---@class GameCore.BaseBehaviour : UnityEngine.MonoBehaviour
local m = {}
GameCore = {}
GameCore.BaseBehaviour = m
return m