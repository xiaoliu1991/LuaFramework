---@class GameCore.BaseLogger : object
---@field isDebug bool
---@field level GameCore.LogLevel
local m = {}
---@overload fun(message:object, content:UnityEngine.Object):void
---@param content object
function m.Log(content) end
---@param format string
---@param args table
function m.LogFormat(format, args) end
---@param format string
---@param color string
---@param forceLog bool
function m.LogColor(format, color, forceLog) end
---@overload fun(message:object, content:UnityEngine.Object):void
---@param content object
function m.LogWarning(content) end
---@param format string
---@param args table
function m.LogWarningFormat(format, args) end
---@overload fun(message:object, content:UnityEngine.Object):void
---@param content object
function m.LogError(content) end
---@param format string
---@param args table
function m.LogErrorFormat(format, args) end
GameCore = {}
GameCore.BaseLogger = m
return m