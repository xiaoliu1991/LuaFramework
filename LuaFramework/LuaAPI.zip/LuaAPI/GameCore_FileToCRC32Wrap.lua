---@class GameCore.FileToCRC32 : object
local m = {}
---@param filePath string
---@return string
function m.GetFileCRC32(filePath) end
---@param str string
---@return string
function m.GetStrCRC32(str) end
---@param bytes table
---@return string
function m.GetCRC32(bytes) end
GameCore = {}
GameCore.FileToCRC32 = m
return m