---@class GameCore.FileUtils
local m = {}
---@param inPath string
---@param outPath string
function m.CopyFile(inPath, outPath) end
---@param path string
function m.CreateDirectory(path) end
---@param path string
---@param text string
function m.WriteAllText(path, text) end
---@param path string
---@param bytes table
function m.WriteAllBytes(path, bytes) end
---@param inFile string
---@param outFile string
function m.MoveFile(inFile, outFile) end
---@param fromDir string
---@param toDir string
function m.CopyDir(fromDir, toDir) end
---@param dir string
---@param allFiles table
---@param allDics table
function m.GetAllFilesInPath(dir, allFiles, allDics) end
---@param path string
function m.DeletePath(path) end
---@param v string
function m.Delete(v) end
GameCore = {}
GameCore.FileUtils = m
return m