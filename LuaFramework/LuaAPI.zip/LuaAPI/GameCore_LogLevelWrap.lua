---@class GameCore.LogLevel : System.Enum
---@field value__ int
---@field All GameCore.LogLevel
---@field Debug GameCore.LogLevel
---@field Info GameCore.LogLevel
---@field Warn GameCore.LogLevel
---@field Error GameCore.LogLevel
---@field Fatal GameCore.LogLevel
---@field Off GameCore.LogLevel
local m = {}
GameCore = {}
GameCore.LogLevel = m
return m