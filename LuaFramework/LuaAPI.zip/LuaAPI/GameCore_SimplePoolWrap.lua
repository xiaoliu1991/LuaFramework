---@class GameCore.SimplePool : object
---@field UseList table
---@field OnGetOne System.Action
---@field OnCollectOne System.Action
local m = {}
---@param active bool
---@return UnityEngine.GameObject
function m:GetOne(active) end
---@param gameObj UnityEngine.GameObject
---@param isActive bool
function m:CollectOne(gameObj, isActive) end
---@param isActive bool
function m:CollectAll(isActive) end
function m:HideAllUnUse() end
function m:Dispose() end
GameCore = {}
GameCore.SimplePool = m
return m