---@class GameCore.Singleton<GameLogic.ResourcesManager> : object
---@field Instance GameLogic.ResourcesManager
local m = {}
GameCore = {}
GameCore.Singleton<GameLogic = {}
GameCore.Singleton<GameLogic.ResourcesManager> = m
return m