---@class GameCore.Singleton<GameLogic.SceneController> : object
---@field Instance GameLogic.SceneController
local m = {}
GameCore = {}
GameCore.Singleton<GameLogic = {}
GameCore.Singleton<GameLogic.SceneController> = m
return m