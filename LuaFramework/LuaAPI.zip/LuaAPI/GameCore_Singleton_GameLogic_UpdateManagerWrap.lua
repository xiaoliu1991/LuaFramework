---@class GameCore.Singleton<GameLogic.UpdateManager> : object
---@field Instance GameLogic.UpdateManager
local m = {}
GameCore = {}
GameCore.Singleton<GameLogic = {}
GameCore.Singleton<GameLogic.UpdateManager> = m
return m