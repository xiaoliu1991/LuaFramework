---@class GameCore.Singleton<GameLogic.VersionManager> : object
---@field Instance GameLogic.VersionManager
local m = {}
GameCore = {}
GameCore.Singleton<GameLogic = {}
GameCore.Singleton<GameLogic.VersionManager> = m
return m