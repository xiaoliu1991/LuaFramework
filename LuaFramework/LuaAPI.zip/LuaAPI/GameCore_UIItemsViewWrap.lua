---@class GameCore.UIItemsView : UnityEngine.MonoBehaviour
---@field UpdateItem System.Action
---@field prefab UnityEngine.GameObject
local m = {}
---@param count int
function m:Init(count) end
---@return table
function m:GetUseList() end
GameCore = {}
GameCore.UIItemsView = m
return m