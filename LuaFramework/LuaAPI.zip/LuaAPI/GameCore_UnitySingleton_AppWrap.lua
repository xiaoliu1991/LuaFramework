---@class GameCore.UnitySingleton<App> : UnityEngine.MonoBehaviour
---@field Instance App
local m = {}
GameCore = {}
GameCore.UnitySingleton<App> = m
return m