---@class GameCore.UnitySingleton<GameLogic.BuglySdkManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.BuglySdkManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.BuglySdkManager> = m
return m