---@class GameCore.UnitySingleton<GameLogic.GameManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.GameManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.GameManager> = m
return m