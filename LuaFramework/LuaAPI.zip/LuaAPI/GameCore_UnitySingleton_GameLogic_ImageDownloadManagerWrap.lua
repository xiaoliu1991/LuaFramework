---@class GameCore.UnitySingleton<GameLogic.ImageDownloadManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.ImageDownloadManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.ImageDownloadManager> = m
return m