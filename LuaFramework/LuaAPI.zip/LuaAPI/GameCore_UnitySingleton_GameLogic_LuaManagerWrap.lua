---@class GameCore.UnitySingleton<GameLogic.LuaManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.LuaManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.LuaManager> = m
return m