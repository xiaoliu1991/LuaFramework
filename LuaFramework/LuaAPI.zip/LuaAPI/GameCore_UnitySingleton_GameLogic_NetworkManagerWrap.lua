---@class GameCore.UnitySingleton<GameLogic.NetworkManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.NetworkManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.NetworkManager> = m
return m