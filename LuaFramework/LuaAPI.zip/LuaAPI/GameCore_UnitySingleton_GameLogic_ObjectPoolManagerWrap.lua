---@class GameCore.UnitySingleton<GameLogic.ObjectPoolManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.ObjectPoolManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.ObjectPoolManager> = m
return m