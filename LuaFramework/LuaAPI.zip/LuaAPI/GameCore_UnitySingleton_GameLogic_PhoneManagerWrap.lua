---@class GameCore.UnitySingleton<GameLogic.PhoneManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.PhoneManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.PhoneManager> = m
return m