---@class GameCore.UnitySingleton<GameLogic.SDKManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.SDKManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.SDKManager> = m
return m