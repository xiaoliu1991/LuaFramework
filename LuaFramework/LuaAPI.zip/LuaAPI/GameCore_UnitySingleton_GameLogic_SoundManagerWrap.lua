---@class GameCore.UnitySingleton<GameLogic.SoundManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.SoundManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.SoundManager> = m
return m