---@class GameCore.UnitySingleton<GameLogic.WebSocketManager> : UnityEngine.MonoBehaviour
---@field Instance GameLogic.WebSocketManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<GameLogic = {}
GameCore.UnitySingleton<GameLogic.WebSocketManager> = m
return m