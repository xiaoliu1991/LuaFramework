---@class GameCore.UnitySingleton<ResUpdate.ResourcesUpdateManager> : UnityEngine.MonoBehaviour
---@field Instance ResUpdate.ResourcesUpdateManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<ResUpdate = {}
GameCore.UnitySingleton<ResUpdate.ResourcesUpdateManager> = m
return m