---@class GameCore.UnitySingleton<WebManager> : UnityEngine.MonoBehaviour
---@field Instance WebManager
local m = {}
GameCore = {}
GameCore.UnitySingleton<WebManager> = m
return m