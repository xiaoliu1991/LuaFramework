---@class GameHelper : object
local m = {}
---@param game string
function m.AddGameLuaSearchPath(game) end
---@param game string
function m.RemoveGameLuaSearchPath(game) end
GameHelper = m
return m