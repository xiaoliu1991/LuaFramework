---@class GameLogic.BuglySdkManager : GameCore.UnitySingleton
local m = {}
---@param userId string
function m:SetUserId(userId) end
---@param channel string
---@param version string
---@param user string
---@param delay long
function m:SetVersion(channel, version, user, delay) end
GameLogic = {}
GameLogic.BuglySdkManager = m
return m