---@class GameLogic.Button3D : UnityEngine.MonoBehaviour
---@field onClick UnityEngine.Events.UnityAction
local m = {}
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end
GameLogic = {}
GameLogic.Button3D = m
return m