---@class GameLogic.GameEvent : object
local m = {}
---@param type string
---@param handler GameLogic.GameEventHandler
---@param isUseOnce bool
function m:AddEvent(type, handler, isUseOnce) end
---@overload fun(type:string):void
---@overload fun():void
---@param type string
---@param handler GameLogic.GameEventHandler
function m:RemoveEvent(type, handler) end
---@param type string
---@param args table
function m:DispatchEvent(type, args) end
---@param type string
---@param args table
function m:DispatchAsyncEvent(type, args) end
---@param type string
---@return bool
function m:HasEvent(type) end
function m:UpdateEvent() end
---@param updateEvent GameLogic.GameEventHandler
---@param loopTimes int
function m:AddUpdateEvent(updateEvent, loopTimes) end
---@param updateEvent GameLogic.GameEventHandler
function m:RemoveUpdateEvent(updateEvent) end
function m:Dispose() end
GameLogic = {}
GameLogic.GameEvent = m
return m