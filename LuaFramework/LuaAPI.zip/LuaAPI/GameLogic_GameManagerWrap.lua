---@class GameLogic.GameManager : GameCore.UnitySingleton
local m = {}
function m:Restart() end
function m:Reset() end
---@param updateEvent System.Action
---@param loopTime int
function m:AddUpdateEvent(updateEvent, loopTime) end
---@param updateEvent System.Action
function m:RemoveUpdateEvent(updateEvent) end
GameLogic = {}
GameLogic.GameManager = m
return m