---@class GameLogic.GameObjectPool : object
local m = {}
---@param isActive bool
---@return UnityEngine.GameObject
function m:NextAvailableObject(isActive) end
---@param pool string
---@param po UnityEngine.GameObject
function m:ReturnObjectToPool(pool, po) end
function m:ClearGameObjectPool() end
GameLogic = {}
GameLogic.GameObjectPool = m
return m