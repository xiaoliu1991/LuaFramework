---@class GameLogic.GlobalEvent : GameLogic.GameEvent
---@field inst GameLogic.GlobalEvent
local m = {}
---@param type string
---@param handler GameLogic.GameEventHandler
---@param isUseOnce bool
function m.add(type, handler, isUseOnce) end
---@overload fun(type:string):void
---@overload fun():void
---@param type string
---@param handler GameLogic.GameEventHandler
function m.remove(type, handler) end
---@param type string
---@param args table
function m.dispatch(type, args) end
---@param type string
---@param args table
function m.dispatchAsync(type, args) end
---@param type string
---@return bool
function m.hasEvent(type) end
function m.updateEvent() end
function m.dispose() end
---@param eName string
---@param handler GameLogic.GameEventHandler
function m.AddLuaEvent(eName, handler) end
---@param eName string
---@param handler GameLogic.GameEventHandler
function m.RemoveLuaEvent(eName, handler) end
---@param eName string
---@param args table
function m.DispatchLuaEvent(eName, args) end
---@param updateEvent GameLogic.GameEventHandler
---@param loopTimes int
function m.addUpdateEvent(updateEvent, loopTimes) end
---@param updateEvent GameLogic.GameEventHandler
function m.removeUpdateEvent(updateEvent) end
GameLogic = {}
GameLogic.GlobalEvent = m
return m