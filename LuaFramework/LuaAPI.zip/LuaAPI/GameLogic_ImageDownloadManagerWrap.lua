---@class GameLogic.ImageDownloadManager : GameCore.UnitySingleton
local m = {}
function m:Reset() end
---@param url string
---@param obj UnityEngine.GameObject
---@param isSelf bool
function m:SetImage_GameObject(url, obj, isSelf) end
---@param url string
---@param image UnityEngine.UI.Image
---@param isSelfImg bool
function m:SetImage_Image(url, image, isSelfImg) end
GameLogic = {}
GameLogic.ImageDownloadManager = m
return m