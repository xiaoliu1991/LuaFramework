---@class GameLogic.Lua3DTrigger : UnityEngine.MonoBehaviour
---@field onTriggerEnter UnityEngine.Events.UnityAction
---@field onTriggerExit UnityEngine.Events.UnityAction
---@field onTriggerStay UnityEngine.Events.UnityAction
local m = {}
function m:Clear() end
GameLogic = {}
GameLogic.Lua3DTrigger = m
return m