---@class GameLogic.LuaBehaviour : UnityEngine.MonoBehaviour
---@field game string
local m = {}
---@param go UnityEngine.GameObject
---@param luafunc LuaInterface.LuaFunction
function m:AddClick(go, luafunc) end
---@param root UnityEngine.GameObject
---@param btnName string
---@param luafunc LuaInterface.LuaFunction
function m:AddClickToChild(root, btnName, luafunc) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m:AddToggle(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m:AddInputField_OnValueChanged(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m:AddInputField_OnEndEdit(go, func) end
---@param go UnityEngine.GameObject
function m:RemoveClick(go) end
function m:ClearClick() end
GameLogic = {}
GameLogic.LuaBehaviour = m
return m