---@class GameLogic.LuaHelper
local m = {}
---@param classname string
---@return System.Type
function m.GetType(classname) end
---@param data LuaInterface.LuaByteBuffer
---@param func LuaInterface.LuaFunction
function m.OnCallLuaFunc(data, func) end
---@param data string
---@param func LuaInterface.LuaFunction
function m.OnJsonCallFunc(data, func) end
GameLogic = {}
GameLogic.LuaHelper = m
return m