---@class GameLogic.LuaLoader : LuaInterface.LuaFileUtils
---@field beZip bool
local m = {}
function m:InitConfigs() end
---@param bundleName string
function m:AddBundle(bundleName) end
---@param fileName string
---@return table
function m:ReadFile(fileName) end
GameLogic = {}
GameLogic.LuaLoader = m
return m