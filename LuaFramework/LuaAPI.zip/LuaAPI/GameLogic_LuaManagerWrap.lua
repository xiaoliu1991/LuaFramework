---@class GameLogic.LuaManager : GameCore.UnitySingleton
local m = {}
function m:InitLua() end
function m:InitStart() end
---@param path string
function m:AddSearchPath(path) end
---@param path string
function m:RemoveSearchPath(path) end
---@param Path string
---@param FunctionName string
function m:CallLuaFunction(Path, FunctionName) end
---@param filename string
function m:DoFile(filename) end
---@param funcName string
---@param args table
function m:CallFunction(funcName, args) end
function m:LuaGC() end
function m:Close() end
---@return bool
function m:CanUseLua() end
function m:AttachProfiler() end
function m:DetachProfiler() end
function m:Reset() end
GameLogic = {}
GameLogic.LuaManager = m
return m