---@class GameLogic.NetworkManager : GameCore.UnitySingleton
local m = {}
function m:Reset() end
function m:ClearNetwork() end
function m:OnInit() end
function m:Unload() end
---@param func string
---@param args table
function m:CallMethod(func, args) end
---@param msgId int
---@param sId uint
---@param msg GameLogic.ByteBuffer
function m.DispatchMessage(msgId, sId, msg) end
function m:StopConnectCo() end
---@param _eventId int
---@param sid uint
---@param data GameLogic.ByteBuffer
function m.AddEvent(_eventId, sid, data) end
---@param info GameLogic.NetworkStateInfo
function m.EnqueueStateInfo(info) end
---@param isNeedConnect bool
function m:SendConnect(isNeedConnect) end
---@param isLoginSuccess bool
function m:SetLoginState(isLoginSuccess) end
---@param isNeedReconnect bool
function m:SendReconnect(isNeedReconnect) end
---@param msgId int
---@param handle System.Action
function m:RegistNetMessage(msgId, handle) end
---@param msgId int
---@param handle System.Action
function m:UnregistNetMessage(msgId, handle) end
---@param buffer GameLogic.ByteBuffer
function m:PostMessage(buffer) end
---@overload fun(pf:int, message:GameLogic.ByteBuffer, callback:System.Action, timeOut:float, timeOutCallBack:System.Action):void
---@param buffer GameLogic.ByteBuffer
function m:SendMessage(buffer) end
---@param isNeedReconnect bool
function m:Disconnect(isNeedReconnect) end
---@param url string
---@param callback LuaInterface.LuaFunction
---@param sharpFunc System.Action
---@param errorAction System.Action
---@param errorLuaFunc LuaInterface.LuaFunction
function m:SendGetHttp(url, callback, sharpFunc, errorAction, errorLuaFunc) end
---@param url string
---@param data string
---@param callback LuaInterface.LuaFunction
---@param errorLuaFunc LuaInterface.LuaFunction
function m:SendHttpPost_Raw_Lua(url, data, callback, errorLuaFunc) end
---@param url string
---@param data string
---@param callback LuaInterface.LuaFunction
---@param errorLuaFunc LuaInterface.LuaFunction
function m:SendHttpPost_Json_Lua(url, data, callback, errorLuaFunc) end
---@param url string
---@param data string
---@param sharpFunc System.Action
---@param errorAction System.Action
function m:SendHttpPost_Raw_CSharp(url, data, sharpFunc, errorAction) end
---@param url string
---@param data string
---@param sharpFunc System.Action
---@param errorAction System.Action
function m:SendHttpPost_Json_CSharp(url, data, sharpFunc, errorAction) end
---@param url string
---@param data string
---@param callback LuaInterface.LuaFunction
---@param sharpFunc System.Action
---@param errorAction System.Action
---@param errorLuaFunc LuaInterface.LuaFunction
---@return System.Collections.IEnumerator
function m:HttpPost_Co(url, data, callback, sharpFunc, errorAction, errorLuaFunc) end
---@return bool
function m:IsConnected() end
GameLogic = {}
GameLogic.NetworkManager = m
return m