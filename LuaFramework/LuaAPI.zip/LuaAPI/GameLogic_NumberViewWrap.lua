---@class GameLogic.NumberView : GameCore.BaseBehaviour
---@field Value int
---@field Prefix string
local m = {}
function m:Clear() end
GameLogic = {}
GameLogic.NumberView = m
return m