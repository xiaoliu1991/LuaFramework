---@class GameLogic.ObjectPoolManager : GameCore.UnitySingleton
local m = {}
---@param poolName string
---@param initSize int
---@param prefab UnityEngine.GameObject
---@param isAutoCreate bool
---@return GameLogic.GameObjectPool
function m:CreatePool(poolName, initSize, prefab, isAutoCreate) end
---@param poolName string
---@return GameLogic.GameObjectPool
function m:GetPool(poolName) end
---@param poolName string
---@param isActive bool
---@return UnityEngine.GameObject
function m:Get(poolName, isActive) end
---@param poolName string
---@param go UnityEngine.GameObject
function m:Release(poolName, go) end
function m:DestoryAllObjectPool() end
function m:DestoryAllGameObjectPool() end
function m:Reset() end
GameLogic = {}
GameLogic.ObjectPoolManager = m
return m