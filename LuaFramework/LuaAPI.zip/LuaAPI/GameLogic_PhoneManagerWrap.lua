---@class GameLogic.PhoneManager : GameCore.UnitySingleton
---@field MainActivity UnityEngine.AndroidJavaObject
local m = {}
---@param payType int
---@param appId string
---@param partnerId string
---@param apiKey string
---@param totalfee string
---@param bodyStr string
---@param notifyUrl string
---@param isCreditCard bool
---@param callBackBackObjectName string
---@param callBackFunctionName string
function m.LocalTestAppPay(payType, appId, partnerId, apiKey, totalfee, bodyStr, notifyUrl, isCreditCard, callBackBackObjectName, callBackFunctionName) end
---@param payType int
---@param appid string
---@param tokenId string
---@param callBackBackObjectName string
---@param onScuessPay LuaInterface.LuaFunction
---@param onFailPay LuaInterface.LuaFunction
---@param onUserCancel LuaInterface.LuaFunction
function m.AppPay(payType, appid, tokenId, callBackBackObjectName, onScuessPay, onFailPay, onUserCancel) end
---@param msg string
function m:PayCallBack(msg) end
function m:BatteryValue() end
---@return UnityEngine.NetworkReachability
function m.GetNetworkReachabilityType() end
---@return float
function m:GetBatteryValue() end
---@return int
function m:GetNetType() end
---@return string
function m:TimeYear() end
---@return string
function m:TimeMonth() end
---@return string
function m:TimeDay() end
---@return string
function m:TimeHour() end
---@return string
function m:TimeMinute() end
GameLogic = {}
GameLogic.PhoneManager = m
return m