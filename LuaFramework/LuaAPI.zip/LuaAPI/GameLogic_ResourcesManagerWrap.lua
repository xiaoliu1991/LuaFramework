---@class GameLogic.ResourcesManager : GameCore.Singleton
---@field isLoading bool
local m = {}
---@param isReleaseVer bool
function m:Initialize(isReleaseVer) end
---@param game string
---@param assetName string
---@return UnityEngine.Object
function m:LoadAsset(game, assetName) end
---@param game string
---@param assetName string
---@param luaFunction LuaInterface.LuaFunction
function m:LoadAssetAsync(game, assetName, luaFunction) end
---@param game string
---@param assetName string
function m:UnLoadAsset(game, assetName) end
---@param game string
function m:UnLoadGame(game) end
---@param game string
function m:UnLoadUnUseAssetAndAssetBundle(game) end
---@param game string
---@param asset string
---@return bool
function m:HaveAsset(game, asset) end
function m:UnLoadAll() end
function m:Reset() end
GameLogic = {}
GameLogic.ResourcesManager = m
return m