---@class GameLogic.SDKManager : GameCore.UnitySingleton
---@field downloadProcessUpdateCallBack System.Action
---@field downloadErrorCallBack System.Action
local m = {}
function m:Initialize() end
---@param url string
---@param outTime long
function m:GetInstallParams(url, outTime) end
---@param curPlatform int
function m:SaveSession(curPlatform) end
function m:ClearSession() end
---@param objName string
function m:Init(objName) end
---@param userId string
function m:SetUserId(userId) end
---@param channel string
---@param version string
---@param user string
---@param delay long
function m:BuglySetVersion(channel, version, user, delay) end
---@return string
function m.GetPackageName() end
---@return string
function m.GetAppVersion() end
---@return string
function m.GetDeviceID() end
---@return string
function m.GetPlatform() end
---@return string
function m.GetDeviceSystemModel() end
---@return string
function m.GetDeviceSystemVersion() end
---@return string
function m.GetDeviceSystemInfo() end
---@return string
function m.GetLocalIP() end
---@return string
function m.GetPublicIp() end
---@param publicIp string
---@param scuessEvent GameLogic.GameEventHandler
---@param failEvent GameLogic.GameEventHandler
function m.GetRegionName(publicIp, scuessEvent, failEvent) end
---@return float
function m.GetDeviceBattary() end
---@return int
function m:GetNetType() end
---@return int
function m:GetWifiInfo() end
function m:WeChat_OpenWXApp() end
---@param callback LuaInterface.LuaFunction
function m:Wechat_Authorize(callback) end
---@param data string
function m:onAuthorize_Success(data) end
---@param data string
function m:onAuthorize_Cancle(data) end
---@param url string
---@param downMsgDelegate System.Action
---@param downloadErrorDelegate System.Action
function m:DownloadApk(url, downMsgDelegate, downloadErrorDelegate) end
---@param url string
function m:InstallApk(url) end
---@param data string
function m:onDownLoadUpdate(data) end
---@param data string
function m:onDownLoadError(data) end
---@param texture UnityEngine.Texture2D
---@param fileName string
---@param callback LuaInterface.LuaFunction
function m:SaveTextureToAlbum(texture, fileName, callback) end
---@param result string
function m:SaveImageToPhotosAlumCallBack(result) end
---@param type int
---@param defaultValue string
---@param compressSize int
---@param onInputViewClose LuaInterface.LuaFunction
---@param onInputSendMsg LuaInterface.LuaFunction
---@param onInputViewHeightChange LuaInterface.LuaFunction
---@param takePhotoResult LuaInterface.LuaFunction
function m:ShowInputView(type, defaultValue, compressSize, onInputViewClose, onInputSendMsg, onInputViewHeightChange, takePhotoResult) end
---@param imagePath string
function m:OpenTakePhotoResult(imagePath) end
---@param msg string
function m:OnInputViewClose(msg) end
---@param msg string
function m:OnInputSendMsg(msg) end
---@param strHeight string
function m:OnInputViewHeightChange(strHeight) end
---@param title string
---@param description string
---@param url string
---@param imagePath string
---@param type int
---@param wechatShareSuccessP LuaInterface.LuaFunction
---@param wechatShareCancleP LuaInterface.LuaFunction
function m:Wechat_ShareWebUrlToWX(title, description, url, imagePath, type, wechatShareSuccessP, wechatShareCancleP) end
---@param msg string
function m:Wechat_ShareWebUrlToWX_Success(msg) end
---@param msg string
function m:Wechat_ShareWebUrlToWX_Cancle(msg) end
---@param imagePath string
---@param type int
---@param wechatShareSuccessP LuaInterface.LuaFunction
---@param wechatShareCancleP LuaInterface.LuaFunction
function m:Wechat_ShareLocalImageToWX(imagePath, type, wechatShareSuccessP, wechatShareCancleP) end
---@param msg string
function m:Wechat_ShareLocalImgToWX_Success(msg) end
---@param msg string
function m:Wechat_ShareLocalImgToWX_Cancle(msg) end
---@param wechatShareSuccessP LuaInterface.LuaFunction
---@param wechatShareCancleP LuaInterface.LuaFunction
---@param type int
function m:ShareScreenShot(wechatShareSuccessP, wechatShareCancleP, type) end
---@param text string
---@param type int
---@param wechatShareSuccessP LuaInterface.LuaFunction
---@param wechatShareCancleP LuaInterface.LuaFunction
function m:Wechat_ShareTextToWX(text, type, wechatShareSuccessP, wechatShareCancleP) end
---@param title string
---@param description string
---@param musicUrl string
---@param imagePath string
---@param type int
---@param wechatShareSuccessP LuaInterface.LuaFunction
---@param wechatShareCancleP LuaInterface.LuaFunction
function m:Wechat_ShareMusicUrlToWX(title, description, musicUrl, imagePath, type, wechatShareSuccessP, wechatShareCancleP) end
---@param title string
---@param description string
---@param videoUrl string
---@param imagePath string
---@param type int
---@param wechatShareSuccessP LuaInterface.LuaFunction
---@param wechatShareCancleP LuaInterface.LuaFunction
function m:Wechat_ShareVideoUrlToWX(title, description, videoUrl, imagePath, type, wechatShareSuccessP, wechatShareCancleP) end
---@param text string
function m:CopText2Clipboard(text) end
---@return string
function m:GetTextFromClipboard() end
---@param getLocInfoSuccessP LuaInterface.LuaFunction
function m:GetGpsLocInfo(getLocInfoSuccessP) end
---@param msg string
function m:BaiduMapGetLocInfoSuccess(msg) end
---@param lat1 double
---@param lon1 double
---@param lat2 double
---@param lon2 double
---@return double
function m:Distance(lat1, lon1, lat2, lon2) end
---@param degrees double
---@return double
function m.ConvertDegreesToRadians(degrees) end
---@param radian double
---@return double
function m.ConvertRadiansToDegrees(radian) end
---@param theta double
---@return double
function m.HaverSin(theta) end
---@param UserId string
---@param qudao string
function m:InitLoginUmengSdk(UserId, qudao) end
---@param lv int
function m:PlayLvUp(lv) end
---@param UserId string
---@param Rmb int
---@param daojuCount int
function m:Pay(UserId, Rmb, daojuCount) end
function m:Exit() end
---@param UserId string
function m:RegisterTimeClec(UserId) end
---@param UserId string
function m:LoginTime(UserId) end
---@param UserId string
function m:LogOutTime(UserId) end
---@param UserId string
---@param UName string
---@param Gold string
---@param Diamond string
---@param HeadPic string
function m:UserInfoClec(UserId, UName, Gold, Diamond, HeadPic) end
---@param UserId string
---@param gametype string
---@param roomId string
---@param cardInfo string
---@param GameResult string
---@param systemGetMoney string
function m:JoinGameInfoClec(UserId, gametype, roomId, cardInfo, GameResult, systemGetMoney) end
---@param money string
---@param type string
function m:SystemGetMoneyClec(money, type) end
---@param winLoseType string
function m:SystemWinLoseClec(winLoseType) end
---@param startGamePeopleCount string
function m:PeopleAndGameClec(startGamePeopleCount) end
GameLogic = {}
GameLogic.SDKManager = m
return m