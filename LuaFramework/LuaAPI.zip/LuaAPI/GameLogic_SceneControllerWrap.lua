---@class GameLogic.SceneController : GameCore.Singleton
local m = {}
---@param name string
---@param func LuaInterface.LuaFunction
function m:LoadScene(name, func) end
GameLogic = {}
GameLogic.SceneController = m
return m