---@class GameLogic.ServerConfig : object
---@field serverConfig GameLogic.ServerConfig
---@field join_addr string
---@field server_addroot string
---@field server_Ip string
---@field server_Port int
---@field maintain_status int
---@field appkey string
---@field extent table
local m = {}
GameLogic = {}
GameLogic.ServerConfig = m
return m