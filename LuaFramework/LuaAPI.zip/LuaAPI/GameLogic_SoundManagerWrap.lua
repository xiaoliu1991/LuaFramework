---@class GameLogic.SoundManager : GameCore.UnitySingleton
---@field MusicVolume float
---@field AduioVolume float
---@field IsPlayMusic bool
---@field IsPlayAudio bool
local m = {}
---@param game string
---@param name string
function m:PlayMusic(game, name) end
---@param game string
---@param name string
function m:PlayAudio(game, name) end
function m:StopAllAudio() end
GameLogic = {}
GameLogic.SoundManager = m
return m