---@class GameLogic.UIDepthAdapter : UnityEngine.MonoBehaviour
local m = {}
GameLogic = {}
GameLogic.UIDepthAdapter = m
return m