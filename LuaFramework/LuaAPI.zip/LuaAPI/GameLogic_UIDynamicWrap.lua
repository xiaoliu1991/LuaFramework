---@class GameLogic.UIDynamic : UnityEngine.MonoBehaviour
---@field useList table
---@field scrollRectTrans UnityEngine.RectTransform
---@field UpdateItem UnityEngine.Events.UnityAction
---@field CollectItem UnityEngine.Events.UnityAction
---@field arrangement GameLogic.UIDynamic.Arrangement
---@field maxPerLine int
---@field cellWidth float
---@field cellHeight float
---@field widthSpace float
---@field hegithSpace float
---@field viewCount int
---@field scrollRect UnityEngine.UI.ScrollRect
---@field content UnityEngine.RectTransform
---@field goItemPrefab UnityEngine.GameObject
local m = {}
---@param dataCount int
function m:Init(dataCount) end
---@param index int
function m:JumpToIndex(index) end
GameLogic = {}
GameLogic.UIDynamic = m
return m