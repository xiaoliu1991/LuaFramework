---@class GameLogic.UpdateManager : GameCore.Singleton
local m = {}
function m:StartUp() end
---@return string
function m:PostServerInfo() end
---@overload fun(game:string, action:System.Action, gameConfigText:string):void
---@param game string
---@param action System.Action
function m:UpdateResources(game, action) end
function m:UnLoadUpdateAsset() end
GameLogic = {}
GameLogic.UpdateManager = m
return m