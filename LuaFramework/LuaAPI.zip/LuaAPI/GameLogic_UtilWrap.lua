---@class GameLogic.Util : object
---@field DataPath string
---@field NetAvailable bool
---@field IsWifi bool
---@field packGameVersion string
---@field updateGameVersion string
---@field netGameVersion string
---@field gray UnityEngine.Color
local m = {}
---@return string
function m.GetDownloadPackageUrl() end
---@param fileName string
---@return bool
function m.IsFileExist(fileName) end
---@return bool
function m.IsExracted() end
---@return bool
function m.NeedExtractResource() end
---@param version1 string
---@param version2 string
---@return int
function m.CompareGameVersion(version1, version2) end
---@param mHost string
---@param mPort string
---@return string
function m.GetIPv6(mHost, mPort) end
---@param serverIp string
---@param serverPorts string
---@param newServerIp string
---@param mIPType System.Net.Sockets.AddressFamily
function m.getIPType(serverIp, serverPorts, newServerIp, mIPType) end
---@param o object
---@return int
function m.Int(o) end
---@param o object
---@return float
function m.Float(o) end
---@param o object
---@return long
function m.Long(o) end
---@overload fun(min:float, max:float):float
---@param min int
---@param max int
---@return int
function m.Random(min, max) end
---@param uid string
---@return string
function m.Uid(uid) end
---@return long
function m.GetTime() end
---@return string
function m.GetDateTime() end
---@return string
function m.GetPlatformVersion() end
---@param go UnityEngine.GameObject
---@return GameLogic.EventTriggerListener
function m.GetEventTriggerListener(go) end
---@param go UnityEngine.GameObject
---@return GameLogic.EventTriggerListener
function m.GetEventTriggerListenerWithNil(go) end
---@overload fun(go:UnityEngine.Transform, subnode:string):UnityEngine.GameObject
---@param go UnityEngine.GameObject
---@param subnode string
---@return UnityEngine.GameObject
function m.Child(go, subnode) end
---@overload fun(root:UnityEngine.Transform, objName:string):UnityEngine.GameObject
---@param root UnityEngine.GameObject
---@param objName string
---@return UnityEngine.GameObject
function m.GetGameObject(root, objName) end
---@overload fun(go:UnityEngine.Transform, subnode:string):UnityEngine.GameObject
---@param go UnityEngine.GameObject
---@param subnode string
---@return UnityEngine.GameObject
function m.Peer(go, subnode) end
---@param source string
---@return string
function m.md5(source) end
---@param file string
---@return string
function m.md5file(file) end
---@param buffer table
---@return string
function m.md5bytes(buffer) end
---@param go UnityEngine.Transform
function m.ClearChild(go) end
function m.ClearMemory() end
---@return string
function m.GetRelativePath() end
---@return string
function m.GetOriginalPath() end
---@return string
function m.GetAvaliableRelativePath() end
---@return string
function m.GetAvaliableRelativePath_File() end
---@return string
function m.GetOriginalPath_File() end
---@return string
function m.GetRelativePath_File() end
---@return string
function m.AppContentPath() end
---@return string
function m.AppRootPath() end
---@param path string
---@return string
function m.GetFileText(path) end
---@param level int
function m.SetLogLevel(level) end
---@param pars table
function m.Log(pars) end
---@param str string
function m.LogWarning(str) end
---@param str string
function m.LogError(str) end
---@param str string
---@param color string
---@param forceLog bool
function m.LogColor(str, color, forceLog) end
---@return int
function m.CheckRuntimeFile() end
---@param module string
---@param func string
---@param args table
function m.CallMethod(module, func, args) end
---@param msgID string
---@param data object
function m.CallLuaMessage(msgID, data) end
---@return bool
function m.CheckEnvironment() end
---@param go UnityEngine.GameObject
---@param luafunc LuaInterface.LuaFunction
function m.AddClick(go, luafunc) end
---@param go UnityEngine.GameObject
---@param luafunc LuaInterface.LuaFunction
function m.AddScrollBar(go, luafunc) end
---@param go UnityEngine.GameObject
---@param luafunc LuaInterface.LuaFunction
function m.AddSlider(go, luafunc) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddToggle(go, func) end
---@param targetObj UnityEngine.GameObject
---@param psScaler float
---@param bUseScale bool
function m.SetParticleScaler(targetObj, psScaler, bUseScale) end
---@overload fun(go:UnityEngine.GameObject, layer:int):void
---@overload fun(go:UnityEngine.GameObject, layer:int, ignoreSetLayer:table):void
---@param go UnityEngine.GameObject
---@param layer int
---@param ignoreLayer int
function m.setLayer(go, layer, ignoreLayer) end
---@param str string
function m.OpenUrl(str) end
function m.SetValueOfSound() end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddDropdown_OnValueChanged(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddInputField_OnValueChanged(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddInputField_OnEndEdit(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddRepeatButton_OnPress(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddRepeatButton_OnRelease(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddRepeatButton_OnExit(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddRepeatButton_OnBeginDrag(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddRepeatButton_OnDrag(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddRepeatButton_OnEndDrag(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddScrollRectOW_OnDrag(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddScrollRectOW_OnBeginDrag(go, func) end
---@param go UnityEngine.GameObject
---@param func LuaInterface.LuaFunction
function m.AddScrollRectOW_OnEndDrag(go, func) end
---@param obj UnityEngine.GameObject
function m.ResetRectTransform(obj) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
function m.SetLocalScale(trans, x, y, z) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
function m.SetLocalPosition(trans, x, y, z) end
---@param trans UnityEngine.Transform
---@param x float
function m.SetLocalX(trans, x) end
---@param trans UnityEngine.Transform
---@param y float
function m.SetLocalY(trans, y) end
---@param trans UnityEngine.Transform
---@param z float
function m.SetLocalZ(trans, z) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
function m.SetLocalRotation(trans, x, y, z) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
---@param duration float
function m.DoLocalMove(trans, x, y, z, duration) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
---@param duration float
function m.DoLocalMoveAdd(trans, x, y, z, duration) end
---@param trans UnityEngine.Transform
---@param target UnityEngine.Transform
---@param x float
---@param y float
---@param z float
---@param duration float
function m.DoMoveToTarget(trans, target, x, y, z, duration) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
---@param duration float
function m.DoLocalRotate(trans, x, y, z, duration) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
---@param duration float
function m.DoLocalScale(trans, x, y, z, duration) end
---@param graphic UnityEngine.UI.Graphic
---@param start UnityEngine.Color
---@param end UnityEngine.Color
---@param duration float
function m.DoColor(graphic, start, end, duration) end
---@param trans UnityEngine.Transform
---@param v1 UnityEngine.Vector3
---@param v2 UnityEngine.Vector3
---@param v3 UnityEngine.Vector3
---@param duration float
---@param pathType DG.Tweening.PathType
---@param pathMode DG.Tweening.PathMode
---@return DG.Tweening.Tweener
function m.DoPath(trans, v1, v2, v3, duration, pathType, pathMode) end
---@param trans UnityEngine.Transform
---@param v1 UnityEngine.Vector3
---@param v2 UnityEngine.Vector3
---@param v3 UnityEngine.Vector3
---@param duration float
---@param pathType DG.Tweening.PathType
---@param pathMode DG.Tweening.PathMode
---@return DG.Tweening.Tweener
function m.DoLocalPath(trans, v1, v2, v3, duration, pathType, pathMode) end
---@param graphic UnityEngine.UI.Graphic
---@param startAlpha float
---@param endAlpha float
---@param duration float
function m.DoColor_Alpha(graphic, startAlpha, endAlpha, duration) end
---@param graphic UnityEngine.UI.Graphic
---@param col UnityEngine.Color
function m.SetColor(graphic, col) end
---@param graphic UnityEngine.UI.Graphic
---@param alpha float
function m.SetColorAlpha_Float(graphic, alpha) end
---@param graphic UnityEngine.UI.Graphic
---@param alpha int
function m.SetColorAlpha_Int(graphic, alpha) end
---@param r float
---@param g float
---@param b float
---@return UnityEngine.Color
function m.GetFloatColor(r, g, b) end
---@param trans UnityEngine.Transform
---@param x float
---@param y float
---@param z float
---@param duration float
function m.DoLoopRotate(trans, x, y, z, duration) end
---@param trans UnityEngine.Transform
---@return table
function m.GetChildrenTrans(trans) end
---@param game string
---@param spriteName string
---@return UnityEngine.Sprite
function m.LoadSprite(game, spriteName) end
---@param game string
---@param spriteName string
---@param image UnityEngine.UI.Image
function m.LoadSpriteAsync(game, spriteName, image) end
---@return bool
function m.IsPointerOverUIObject() end
---@param from UnityEngine.Transform
---@param to UnityEngine.Transform
function m.SetChildrenParent(from, to) end
---@param text string
---@param font UnityEngine.Font
---@param fontsize int
---@return float
function m.GetFontlen(text, font, fontsize) end
function m.ChangeGameViewResulation() end
---@param isForce bool
function m.ChangeGameViewEditorResulation(isForce) end
---@param path string
function m.CaptureUnity(path) end
---@param rect UnityEngine.Rect
---@param path string
---@param action LuaInterface.LuaFunction
function m.CaptureByRect(rect, path, action) end
---@param camera UnityEngine.Camera
---@param rect UnityEngine.Rect
---@param path string
---@param action LuaInterface.LuaFunction
function m.CaptureByCamera(camera, rect, path, action) end
GameLogic = {}
GameLogic.Util = m
return m