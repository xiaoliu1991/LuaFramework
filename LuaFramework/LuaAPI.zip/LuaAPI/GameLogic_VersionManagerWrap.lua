---@class GameLogic.VersionManager : GameCore.Singleton
---@field InternalGames table
local m = {}
function m:Initialize() end
function m:InitVersions() end
---@param game string
---@param version int
function m:SaveVersion(game, version) end
---@param game string
---@return int
function m:GetLocalVersion(game) end
function m:SaveToFiles() end
GameLogic = {}
GameLogic.VersionManager = m
return m