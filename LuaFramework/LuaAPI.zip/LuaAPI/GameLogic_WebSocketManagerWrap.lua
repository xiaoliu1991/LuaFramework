---@class GameLogic.WebSocketManager : GameCore.UnitySingleton
local m = {}
function m:Start() end
---@param url string
---@param luaFile string
---@param loginJson string
function m:Init(url, luaFile, loginJson) end
---@param msg string
function m:SendMsg(msg) end
GameLogic = {}
GameLogic.WebSocketManager = m
return m