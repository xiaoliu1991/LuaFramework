---@class GameObjectExtend : object
local m = {}
---@param obj UnityEngine.GameObject
function m.DestroyObj(obj) end
GameObjectExtend = m
return m