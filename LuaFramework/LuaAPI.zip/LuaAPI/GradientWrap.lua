---@class Gradient : UnityEngine.UI.BaseMeshEffect
---@field topColor UnityEngine.Color32
---@field bottomColor UnityEngine.Color32
local m = {}
---@param top UnityEngine.Color
---@param bottom UnityEngine.Color
function m:SetColor(top, bottom) end
---@param vh UnityEngine.UI.VertexHelper
function m:ModifyMesh(vh) end
Gradient = m
return m