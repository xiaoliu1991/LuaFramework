---@class ImageHelper : UnityEngine.MonoBehaviour
local m = {}
function m:StopCo() end
---@param value float
function m:ResetFillImage(value) end
---@param startValue float
---@param toValue float
---@param time float
function m:FillImage(startValue, toValue, time) end
ImageHelper = m
return m