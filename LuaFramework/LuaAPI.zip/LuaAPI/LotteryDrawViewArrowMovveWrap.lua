---@class LotteryDrawViewArrowMovve : UnityEngine.MonoBehaviour
---@field StopRotation int
local m = {}
---@param Rot int
function m.StartLotteryDraw(Rot) end
LotteryDrawViewArrowMovve = m
return m