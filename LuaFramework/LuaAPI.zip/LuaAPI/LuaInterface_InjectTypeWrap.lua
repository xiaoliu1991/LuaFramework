---@class LuaInterface.InjectType : System.Enum
---@field value__ int
---@field None LuaInterface.InjectType
---@field After LuaInterface.InjectType
---@field Before LuaInterface.InjectType
---@field Replace LuaInterface.InjectType
---@field ReplaceWithPreInvokeBase LuaInterface.InjectType
---@field ReplaceWithPostInvokeBase LuaInterface.InjectType
local m = {}
LuaInterface = {}
LuaInterface.InjectType = m
return m