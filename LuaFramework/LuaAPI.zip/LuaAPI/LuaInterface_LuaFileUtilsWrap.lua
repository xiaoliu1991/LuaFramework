---@class LuaInterface.LuaFileUtils : object
---@field Instance LuaInterface.LuaFileUtils
---@field beZip bool
local m = {}
function m:Dispose() end
---@param path string
---@param front bool
---@return bool
function m:AddSearchPath(path, front) end
---@param path string
---@return bool
function m:RemoveSearchPath(path) end
---@param name string
---@param bundle UnityEngine.AssetBundle
function m:AddSearchBundle(name, bundle) end
---@param fileName string
---@return string
function m:FindFile(fileName) end
---@param fileName string
---@return table
function m:ReadFile(fileName) end
---@param fileName string
---@return string
function m:FindFileError(fileName) end
---@return string
function m.GetOSDir() end
LuaInterface = {}
LuaInterface.LuaFileUtils = m
return m