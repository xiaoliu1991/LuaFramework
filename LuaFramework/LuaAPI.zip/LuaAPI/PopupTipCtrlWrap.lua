---@class PopupTipCtrl : UnityEngine.MonoBehaviour
local m = {}
---@param maxTipsCount int
function m:SetMaxTipsCount(maxTipsCount) end
---@param str string
---@param horiExtend float
---@param verExtend float
---@param upUseTime float
function m:AddTips(str, horiExtend, verExtend, upUseTime) end
PopupTipCtrl = m
return m