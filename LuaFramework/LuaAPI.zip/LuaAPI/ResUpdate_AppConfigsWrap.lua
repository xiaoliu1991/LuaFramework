---@class ResUpdate.AppConfigs : object
---@field appConfigs ResUpdate.AppConfigs
---@field id int
---@field name string
---@field version string
---@field minAllowVersion string
---@field androidURL string
---@field apkSize long
---@field apkCrc string
---@field iosURL string
---@field resURL string
---@field isBanShu bool
---@field isTest bool
local m = {}
---@param localVersion string
---@return bool
function m:CompareVersion(localVersion) end
---@return bool
function m:CompareMiniAllowVersion() end
ResUpdate = {}
ResUpdate.AppConfigs = m
return m