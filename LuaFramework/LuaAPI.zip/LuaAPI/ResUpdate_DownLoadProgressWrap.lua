---@class ResUpdate.DownLoadProgress : object
---@field Size long
---@field SizeKB float
---@field SizeMB float
---@field TotalSize long
---@field TotalSizeKB float
---@field TotalSizeMB float
---@field Progress float
---@field LoadSpeed float
local m = {}
ResUpdate = {}
ResUpdate.DownLoadProgress = m
return m