---@class ResUpdate.ResUpdateProgress : object
---@field SuccessNum int
---@field FailedNum int
---@field TotalNum int
---@field Size long
---@field SizeKB float
---@field SizeMB float
---@field TotalSize long
---@field totalSizeKB float
---@field TotalSizeMB float
---@field Progress float
---@field IsFinish bool
---@field LoadSpeed float
---@field IsSuccess bool
local m = {}
function m:Reset() end
ResUpdate = {}
ResUpdate.ResUpdateProgress = m
return m