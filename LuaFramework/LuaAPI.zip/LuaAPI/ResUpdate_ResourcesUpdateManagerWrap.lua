---@class ResUpdate.ResourcesUpdateManager : GameCore.UnitySingleton
local m = {}
---@param game string
---@param internalGames table
---@param localVersion int
---@param resourcsUpdateAction System.Action
---@param gameConfigText string
function m:BeginUpdate(game, internalGames, localVersion, resourcsUpdateAction, gameConfigText) end
---@param allowDownLoadFromNoWifi bool
function m:BeginDownLoad(allowDownLoadFromNoWifi) end
ResUpdate = {}
ResUpdate.ResourcesUpdateManager = m
return m