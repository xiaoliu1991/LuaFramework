---@class ResUpdate.ResourcesUpdateState : System.Enum
---@field value__ int
---@field GetGameConfigs ResUpdate.ResourcesUpdateState
---@field GetGameConfigsFailed ResUpdate.ResourcesUpdateState
---@field DownLoadVersionFiles ResUpdate.ResourcesUpdateState
---@field DownLoadVersionFilesFailed ResUpdate.ResourcesUpdateState
---@field DownLoadFromNoWifi ResUpdate.ResourcesUpdateState
---@field UpdateResourcesProgress ResUpdate.ResourcesUpdateState
---@field UpdateResourcesFailed ResUpdate.ResourcesUpdateState
---@field Success ResUpdate.ResourcesUpdateState
local m = {}
ResUpdate = {}
ResUpdate.ResourcesUpdateState = m
return m