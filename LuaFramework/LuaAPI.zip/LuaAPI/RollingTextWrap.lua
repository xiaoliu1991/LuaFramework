---@class RollingText : UnityEngine.MonoBehaviour
---@field speed float
---@field moveOverLength float
local m = {}
---@param sharpFun System.Action
---@param luaFun LuaInterface.LuaFunction
function m:SetAllEndCallback(sharpFun, luaFun) end
---@param text string
---@param sharpFun System.Action
---@param luaFun LuaInterface.LuaFunction
function m:AddText(text, sharpFun, luaFun) end
function m:ClearText() end
RollingText = m
return m