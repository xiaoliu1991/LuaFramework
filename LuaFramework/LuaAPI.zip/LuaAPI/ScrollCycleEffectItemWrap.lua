---@class ScrollCycleEffectItem : UnityEngine.MonoBehaviour
---@field rect UnityEngine.RectTransform
---@field img UnityEngine.UI.Image
---@field selectObj UnityEngine.GameObject
---@field unSelectObj UnityEngine.GameObject
---@field v float
---@field sv float
---@field LuaFunc System.Action
local m = {}
---@param _parent ScrollCycleEffect
function m:Init(_parent) end
---@param value float
function m:Drag(value) end
function m:ShowCurrent() end
ScrollCycleEffectItem = m
return m