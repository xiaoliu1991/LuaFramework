---@class ScrollCycleEffect : UnityEngine.MonoBehaviour
---@field Rect UnityEngine.RectTransform
---@field Width float
---@field Height float
---@field MaxScale float
---@field StartValue float
---@field AddValue float
---@field VMin float
---@field VMax float
---@field PositionXCurve UnityEngine.AnimationCurve
---@field ScaleCurve UnityEngine.AnimationCurve
---@field AlphaCurve UnityEngine.AnimationCurve
---@field PositionYCurve UnityEngine.AnimationCurve
---@field _anim_speed float
---@field timelyDisplay bool
---@field Current ScrollCycleEffectItem
local m = {}
function m:Refresh() end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnBeginDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end
---@param _v float
function m:Check(_v) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnEndDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end
---@param gameObject UnityEngine.GameObject
function m:JumpTo(gameObject) end
---@param v float
---@return float
function m:GetAlpha(v) end
---@param v float
---@return float
function m:GetPositionX(v) end
---@param v float
---@return float
function m:GetPositionY(v) end
---@param v float
---@return float
function m:GetScale(v) end
---@return bool
function m:IsAnim() end
---@return bool
function m:IsDraging() end
function m:LateUpdate() end
---@param item ScrollCycleEffectItem
function m:ToLaster(item) end
---@param k float
function m:AnimToEnd(k) end
ScrollCycleEffect = m
return m