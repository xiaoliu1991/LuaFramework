---@class SetInternetPic : object
local m = {}
---@param str string
---@param image UnityEngine.UI.Image
function m.SetInternetPicture(str, image) end
SetInternetPic = m
return m