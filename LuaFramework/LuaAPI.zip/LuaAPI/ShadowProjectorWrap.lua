---@class ShadowProjector : UnityEngine.MonoBehaviour
---@field projector UnityEngine.Projector
---@field lightCamera UnityEngine.Camera
---@field shadowTex UnityEngine.RenderTexture
---@field mainCamera UnityEngine.Camera
---@field shadowCasterList table
---@field boundsCollider UnityEngine.BoxCollider
---@field bgSp UnityEngine.Transform
---@field boundsOffset float
---@field shadowReplaceShader UnityEngine.Shader
---@field IsFinished bool
---@field isAddFish bool
local m = {}
---@param renderer UnityEngine.Renderer
---@param isAdd bool
function m:SetShadowCaster(renderer, isAdd) end
---@param bg UnityEngine.Transform
function m:SetBlackGround(bg) end
ShadowProjector = m
return m