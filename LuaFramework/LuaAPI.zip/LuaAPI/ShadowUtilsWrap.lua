---@class ShadowUtils
local m = {}
---@overload fun(b:UnityEngine.Bounds, lightCamera:UnityEngine.Camera):void
---@param mainCamera UnityEngine.Camera
---@param lightCamera UnityEngine.Camera
function m.SetLightCamera(mainCamera, lightCamera) end
ShadowUtils = m
return m