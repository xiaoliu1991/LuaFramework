---@class Spine.Animation : object
---@field Name string
---@field Timelines Spine.ExposedList
---@field Duration float
local m = {}
---@param skeleton Spine.Skeleton
---@param lastTime float
---@param time float
---@param loop bool
---@param events Spine.ExposedList
---@param alpha float
---@param pose Spine.MixPose
---@param direction Spine.MixDirection
function m:Apply(skeleton, lastTime, time, loop, events, alpha, pose, direction) end
Spine = {}
Spine.Animation = m
return m