---@class Spine.Attachment : object
---@field Name string
local m = {}
---@return string
function m:ToString() end
Spine = {}
Spine.Attachment = m
return m