---@class Spine.BoneData : object
---@field Index int
---@field Name string
---@field Parent Spine.BoneData
---@field Length float
---@field X float
---@field Y float
---@field Rotation float
---@field ScaleX float
---@field ScaleY float
---@field ShearX float
---@field ShearY float
---@field TransformMode Spine.TransformMode
local m = {}
---@return string
function m:ToString() end
Spine = {}
Spine.BoneData = m
return m