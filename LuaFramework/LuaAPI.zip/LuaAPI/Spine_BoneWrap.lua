---@class Spine.Bone : object
---@field Data Spine.BoneData
---@field Skeleton Spine.Skeleton
---@field Parent Spine.Bone
---@field Children Spine.ExposedList
---@field X float
---@field Y float
---@field Rotation float
---@field ScaleX float
---@field ScaleY float
---@field ShearX float
---@field ShearY float
---@field AppliedRotation float
---@field AX float
---@field AY float
---@field AScaleX float
---@field AScaleY float
---@field AShearX float
---@field AShearY float
---@field A float
---@field B float
---@field C float
---@field D float
---@field WorldX float
---@field WorldY float
---@field WorldRotationX float
---@field WorldRotationY float
---@field WorldScaleX float
---@field WorldScaleY float
---@field WorldToLocalRotationX float
---@field WorldToLocalRotationY float
---@field yDown bool
local m = {}
function m:Update() end
---@overload fun(x:float, y:float, rotation:float, scaleX:float, scaleY:float, shearX:float, shearY:float):void
function m:UpdateWorldTransform() end
function m:SetToSetupPose() end
---@param worldX float
---@param worldY float
---@param localX float
---@param localY float
function m:WorldToLocal(worldX, worldY, localX, localY) end
---@param localX float
---@param localY float
---@param worldX float
---@param worldY float
function m:LocalToWorld(localX, localY, worldX, worldY) end
---@param worldRotation float
---@return float
function m:WorldToLocalRotation(worldRotation) end
---@param localRotation float
---@return float
function m:LocalToWorldRotation(localRotation) end
---@param degrees float
function m:RotateWorld(degrees) end
---@return string
function m:ToString() end
Spine = {}
Spine.Bone = m
return m