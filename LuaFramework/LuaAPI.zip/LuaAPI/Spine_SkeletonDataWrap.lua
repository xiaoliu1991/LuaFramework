---@class Spine.SkeletonData : object
---@field Name string
---@field Bones Spine.ExposedList
---@field Slots Spine.ExposedList
---@field Skins Spine.ExposedList
---@field DefaultSkin Spine.Skin
---@field Events Spine.ExposedList
---@field Animations Spine.ExposedList
---@field IkConstraints Spine.ExposedList
---@field TransformConstraints Spine.ExposedList
---@field PathConstraints Spine.ExposedList
---@field Width float
---@field Height float
---@field Version string
---@field Hash string
---@field ImagesPath string
---@field Fps float
local m = {}
---@param boneName string
---@return Spine.BoneData
function m:FindBone(boneName) end
---@param boneName string
---@return int
function m:FindBoneIndex(boneName) end
---@param slotName string
---@return Spine.SlotData
function m:FindSlot(slotName) end
---@param slotName string
---@return int
function m:FindSlotIndex(slotName) end
---@param skinName string
---@return Spine.Skin
function m:FindSkin(skinName) end
---@param eventDataName string
---@return Spine.EventData
function m:FindEvent(eventDataName) end
---@param animationName string
---@return Spine.Animation
function m:FindAnimation(animationName) end
---@param constraintName string
---@return Spine.IkConstraintData
function m:FindIkConstraint(constraintName) end
---@param constraintName string
---@return Spine.TransformConstraintData
function m:FindTransformConstraint(constraintName) end
---@param constraintName string
---@return Spine.PathConstraintData
function m:FindPathConstraint(constraintName) end
---@param pathConstraintName string
---@return int
function m:FindPathConstraintIndex(pathConstraintName) end
---@return string
function m:ToString() end
Spine = {}
Spine.SkeletonData = m
return m