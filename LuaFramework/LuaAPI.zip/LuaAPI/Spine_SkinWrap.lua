---@class Spine.Skin : object
---@field Name string
---@field Attachments table
local m = {}
---@param slotIndex int
---@param name string
---@param attachment Spine.Attachment
function m:AddAttachment(slotIndex, name, attachment) end
---@param slotIndex int
---@param name string
---@return Spine.Attachment
function m:GetAttachment(slotIndex, name) end
---@param slotIndex int
---@param names table
function m:FindNamesForSlot(slotIndex, names) end
---@param slotIndex int
---@param attachments table
function m:FindAttachmentsForSlot(slotIndex, attachments) end
---@return string
function m:ToString() end
Spine = {}
Spine.Skin = m
return m