---@class Spine.SlotData : object
---@field Index int
---@field Name string
---@field BoneData Spine.BoneData
---@field R float
---@field G float
---@field B float
---@field A float
---@field R2 float
---@field G2 float
---@field B2 float
---@field HasSecondColor bool
---@field AttachmentName string
---@field BlendMode Spine.BlendMode
local m = {}
---@return string
function m:ToString() end
Spine = {}
Spine.SlotData = m
return m