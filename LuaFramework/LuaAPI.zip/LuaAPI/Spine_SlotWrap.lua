---@class Spine.Slot : object
---@field Data Spine.SlotData
---@field Bone Spine.Bone
---@field Skeleton Spine.Skeleton
---@field R float
---@field G float
---@field B float
---@field A float
---@field R2 float
---@field G2 float
---@field B2 float
---@field HasSecondColor bool
---@field Attachment Spine.Attachment
---@field AttachmentTime float
---@field AttachmentVertices Spine.ExposedList
local m = {}
function m:SetToSetupPose() end
---@return string
function m:ToString() end
Spine = {}
Spine.Slot = m
return m