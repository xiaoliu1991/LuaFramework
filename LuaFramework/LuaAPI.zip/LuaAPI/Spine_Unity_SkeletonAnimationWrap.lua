---@class Spine.Unity.SkeletonAnimation : Spine.Unity.SkeletonRenderer
---@field AnimationState Spine.AnimationState
---@field AnimationName string
---@field state Spine.AnimationState
---@field loop bool
---@field timeScale float
---@field skeletonDataAsset Spine.Unity.SkeletonDataAsset
---@field initialSkinName string
---@field initialFlipX bool
---@field initialFlipY bool
---@field separatorSlotNames table
---@field separatorSlots table
---@field zSpacing float
---@field useClipping bool
---@field immutableTriangles bool
---@field pmaVertexColors bool
---@field clearStateOnDisable bool
---@field tintBlack bool
---@field singleSubmesh bool
---@field addNormals bool
---@field calculateTangents bool
---@field logErrors bool
---@field disableRenderingOnOverride bool
---@field valid bool
---@field skeleton Spine.Skeleton
local m = {}
---@param gameObject UnityEngine.GameObject
---@param skeletonDataAsset Spine.Unity.SkeletonDataAsset
---@return Spine.Unity.SkeletonAnimation
function m.AddToGameObject(gameObject, skeletonDataAsset) end
---@param skeletonDataAsset Spine.Unity.SkeletonDataAsset
---@return Spine.Unity.SkeletonAnimation
function m.NewSkeletonAnimationGameObject(skeletonDataAsset) end
function m:ClearState() end
---@param overwrite bool
function m:Initialize(overwrite) end
---@param deltaTime float
function m:Update(deltaTime) end
Spine = {}
Spine.Unity = {}
Spine.Unity.SkeletonAnimation = m
return m