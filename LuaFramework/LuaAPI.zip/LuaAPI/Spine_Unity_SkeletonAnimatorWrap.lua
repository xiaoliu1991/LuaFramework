---@class Spine.Unity.SkeletonAnimator : Spine.Unity.SkeletonRenderer
---@field Translator Spine.Unity.SkeletonAnimator.MecanimTranslator
---@field skeletonDataAsset Spine.Unity.SkeletonDataAsset
---@field initialSkinName string
---@field initialFlipX bool
---@field initialFlipY bool
---@field separatorSlotNames table
---@field separatorSlots table
---@field zSpacing float
---@field useClipping bool
---@field immutableTriangles bool
---@field pmaVertexColors bool
---@field clearStateOnDisable bool
---@field tintBlack bool
---@field singleSubmesh bool
---@field addNormals bool
---@field calculateTangents bool
---@field logErrors bool
---@field disableRenderingOnOverride bool
---@field valid bool
---@field skeleton Spine.Skeleton
local m = {}
---@param overwrite bool
function m:Initialize(overwrite) end
function m:Update() end
Spine = {}
Spine.Unity = {}
Spine.Unity.SkeletonAnimator = m
return m