---@class System.IO.Directory
local m = {}
---@param path string
---@return System.IO.DirectoryInfo
function m.CreateDirectory(path) end
---@overload fun(path:string, recursive:bool):void
---@param path string
function m.Delete(path) end
---@param path string
---@return bool
function m.Exists(path) end
---@param path string
---@return System.DateTime
function m.GetLastAccessTime(path) end
---@param path string
---@return System.DateTime
function m.GetLastAccessTimeUtc(path) end
---@param path string
---@return System.DateTime
function m.GetLastWriteTime(path) end
---@param path string
---@return System.DateTime
function m.GetLastWriteTimeUtc(path) end
---@param path string
---@return System.DateTime
function m.GetCreationTime(path) end
---@param path string
---@return System.DateTime
function m.GetCreationTimeUtc(path) end
---@return string
function m.GetCurrentDirectory() end
---@overload fun(path:string, searchPattern:string):table
---@overload fun(path:string, searchPattern:string, searchOption:System.IO.SearchOption):table
---@param path string
---@return table
function m.GetDirectories(path) end
---@param path string
---@return string
function m.GetDirectoryRoot(path) end
---@overload fun(path:string, searchPattern:string):table
---@overload fun(path:string, searchPattern:string, searchOption:System.IO.SearchOption):table
---@param path string
---@return table
function m.GetFiles(path) end
---@overload fun(path:string, searchPattern:string):table
---@param path string
---@return table
function m.GetFileSystemEntries(path) end
---@return table
function m.GetLogicalDrives() end
---@param path string
---@return System.IO.DirectoryInfo
function m.GetParent(path) end
---@param sourceDirName string
---@param destDirName string
function m.Move(sourceDirName, destDirName) end
---@param path string
---@param creationTime System.DateTime
function m.SetCreationTime(path, creationTime) end
---@param path string
---@param creationTimeUtc System.DateTime
function m.SetCreationTimeUtc(path, creationTimeUtc) end
---@param path string
function m.SetCurrentDirectory(path) end
---@param path string
---@param lastAccessTime System.DateTime
function m.SetLastAccessTime(path, lastAccessTime) end
---@param path string
---@param lastAccessTimeUtc System.DateTime
function m.SetLastAccessTimeUtc(path, lastAccessTimeUtc) end
---@param path string
---@param lastWriteTime System.DateTime
function m.SetLastWriteTime(path, lastWriteTime) end
---@param path string
---@param lastWriteTimeUtc System.DateTime
function m.SetLastWriteTimeUtc(path, lastWriteTimeUtc) end
System = {}
System.IO = {}
System.IO.Directory = m
return m