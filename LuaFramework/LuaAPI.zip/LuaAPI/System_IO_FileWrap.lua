---@class System.IO.File
local m = {}
---@overload fun(path:string, contents:string, encoding:System.Text.Encoding):void
---@param path string
---@param contents string
function m.AppendAllText(path, contents) end
---@param path string
---@return System.IO.StreamWriter
function m.AppendText(path) end
---@overload fun(sourceFileName:string, destFileName:string, overwrite:bool):void
---@param sourceFileName string
---@param destFileName string
function m.Copy(sourceFileName, destFileName) end
---@overload fun(path:string, bufferSize:int):System.IO.FileStream
---@param path string
---@return System.IO.FileStream
function m.Create(path) end
---@param path string
---@return System.IO.StreamWriter
function m.CreateText(path) end
---@param path string
function m.Delete(path) end
---@param path string
---@return bool
function m.Exists(path) end
---@param path string
---@return System.IO.FileAttributes
function m.GetAttributes(path) end
---@param path string
---@return System.DateTime
function m.GetCreationTime(path) end
---@param path string
---@return System.DateTime
function m.GetCreationTimeUtc(path) end
---@param path string
---@return System.DateTime
function m.GetLastAccessTime(path) end
---@param path string
---@return System.DateTime
function m.GetLastAccessTimeUtc(path) end
---@param path string
---@return System.DateTime
function m.GetLastWriteTime(path) end
---@param path string
---@return System.DateTime
function m.GetLastWriteTimeUtc(path) end
---@param sourceFileName string
---@param destFileName string
function m.Move(sourceFileName, destFileName) end
---@overload fun(path:string, mode:System.IO.FileMode, access:System.IO.FileAccess):System.IO.FileStream
---@overload fun(path:string, mode:System.IO.FileMode, access:System.IO.FileAccess, share:System.IO.FileShare):System.IO.FileStream
---@param path string
---@param mode System.IO.FileMode
---@return System.IO.FileStream
function m.Open(path, mode) end
---@param path string
---@return System.IO.FileStream
function m.OpenRead(path) end
---@param path string
---@return System.IO.StreamReader
function m.OpenText(path) end
---@param path string
---@return System.IO.FileStream
function m.OpenWrite(path) end
---@overload fun(sourceFileName:string, destinationFileName:string, destinationBackupFileName:string, ignoreMetadataErrors:bool):void
---@param sourceFileName string
---@param destinationFileName string
---@param destinationBackupFileName string
function m.Replace(sourceFileName, destinationFileName, destinationBackupFileName) end
---@param path string
---@param fileAttributes System.IO.FileAttributes
function m.SetAttributes(path, fileAttributes) end
---@param path string
---@param creationTime System.DateTime
function m.SetCreationTime(path, creationTime) end
---@param path string
---@param creationTimeUtc System.DateTime
function m.SetCreationTimeUtc(path, creationTimeUtc) end
---@param path string
---@param lastAccessTime System.DateTime
function m.SetLastAccessTime(path, lastAccessTime) end
---@param path string
---@param lastAccessTimeUtc System.DateTime
function m.SetLastAccessTimeUtc(path, lastAccessTimeUtc) end
---@param path string
---@param lastWriteTime System.DateTime
function m.SetLastWriteTime(path, lastWriteTime) end
---@param path string
---@param lastWriteTimeUtc System.DateTime
function m.SetLastWriteTimeUtc(path, lastWriteTimeUtc) end
---@param path string
---@return table
function m.ReadAllBytes(path) end
---@overload fun(path:string, encoding:System.Text.Encoding):table
---@param path string
---@return table
function m.ReadAllLines(path) end
---@overload fun(path:string, encoding:System.Text.Encoding):string
---@param path string
---@return string
function m.ReadAllText(path) end
---@param path string
---@param bytes table
function m.WriteAllBytes(path, bytes) end
---@overload fun(path:string, contents:table, encoding:System.Text.Encoding):void
---@param path string
---@param contents table
function m.WriteAllLines(path, contents) end
---@overload fun(path:string, contents:string, encoding:System.Text.Encoding):void
---@param path string
---@param contents string
function m.WriteAllText(path, contents) end
---@param path string
function m.Encrypt(path) end
---@param path string
function m.Decrypt(path) end
System = {}
System.IO = {}
System.IO.File = m
return m