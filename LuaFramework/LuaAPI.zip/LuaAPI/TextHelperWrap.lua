---@class TextHelper : UnityEngine.MonoBehaviour
local m = {}
function m:Stop_Co() end
---@param text string
function m:ResetText(text) end
---@param startNumber int
---@param endNumber int
---@param overText string
---@param time float
function m:AddNumberText(startNumber, endNumber, overText, time) end
TextHelper = m
return m