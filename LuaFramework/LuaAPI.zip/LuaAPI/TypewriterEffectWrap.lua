---@class TypewriterEffect : UnityEngine.MonoBehaviour
---@field charsPerSecond float
---@field IsReset bool
local m = {}
---@overload fun(text:string, isTypeWriterEffect:bool, isLoop:bool, charsPerSecond:float):void
---@param subTypeWriterTextIndex int
---@param isLoop bool
---@param charsPerSecond float
---@param subTextes table
function m:ShowText(subTypeWriterTextIndex, isLoop, charsPerSecond, subTextes) end
function m:StartEffect() end
TypewriterEffect = m
return m