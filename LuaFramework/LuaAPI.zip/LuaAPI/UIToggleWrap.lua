---@class UIToggle : UnityEngine.UI.Toggle
---@field toggleTransition UnityEngine.UI.Toggle.ToggleTransition
---@field graphic UnityEngine.UI.Graphic
---@field onValueChanged UnityEngine.UI.Toggle.ToggleEvent
local m = {}
---@param check System.Func
function m:SetCheck(check) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end
UIToggle = m
return m