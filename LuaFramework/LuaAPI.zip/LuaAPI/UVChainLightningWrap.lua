---@class UVChainLightning : UnityEngine.MonoBehaviour
---@field detail float
---@field displacement float
---@field target UnityEngine.Transform
---@field start UnityEngine.Transform
---@field yOffset float
local m = {}
UVChainLightning = m
return m