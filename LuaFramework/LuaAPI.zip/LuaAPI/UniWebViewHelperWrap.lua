---@class UniWebViewHelper : object
local m = {}
---@param path string
---@return string
function m.StreamingAssetURLForPath(path) end
---@param path string
---@return string
function m.PersistentDataURLForPath(path) end
UniWebViewHelper = m
return m