---@class UniWebViewMessage
---@field RawMessage string
---@field Scheme string
---@field Path string
---@field Args table
local m = {}
UniWebViewMessage = m
return m