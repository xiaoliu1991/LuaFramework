---@class UniWebViewNativeListener : UnityEngine.MonoBehaviour
---@field Name string
---@field webView UniWebView
local m = {}
UniWebViewNativeListener = m
return m