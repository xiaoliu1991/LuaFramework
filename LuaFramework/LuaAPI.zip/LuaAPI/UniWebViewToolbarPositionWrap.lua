---@class UniWebViewToolbarPosition : System.Enum
---@field value__ int
---@field Top UniWebViewToolbarPosition
---@field Bottom UniWebViewToolbarPosition
local m = {}
UniWebViewToolbarPosition = m
return m