---@class UniWebViewTransitionEdge : System.Enum
---@field value__ int
---@field None UniWebViewTransitionEdge
---@field Top UniWebViewTransitionEdge
---@field Left UniWebViewTransitionEdge
---@field Bottom UniWebViewTransitionEdge
---@field Right UniWebViewTransitionEdge
local m = {}
UniWebViewTransitionEdge = m
return m