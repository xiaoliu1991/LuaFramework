---@class UniWebView : UnityEngine.MonoBehaviour
---@field Frame UnityEngine.Rect
---@field ReferenceRectTransform UnityEngine.RectTransform
---@field Url string
---@field CanGoBack bool
---@field CanGoForward bool
---@field BackgroundColor UnityEngine.Color
---@field Alpha float
local m = {}
function m:UpdateFrame() end
---@param url string
---@param skipEncoding bool
function m:Load(url, skipEncoding) end
---@param htmlString string
---@param baseUrl string
---@param skipEncoding bool
function m:LoadHTMLString(htmlString, baseUrl, skipEncoding) end
function m:Reload() end
function m:Stop() end
function m:GoBack() end
function m:GoForward() end
---@param flag bool
function m:SetOpenLinksInExternalBrowser(flag) end
---@param fade bool
---@param edge UniWebViewTransitionEdge
---@param duration float
---@param completionHandler System.Action
---@return bool
function m:Show(fade, edge, duration, completionHandler) end
---@param fade bool
---@param edge UniWebViewTransitionEdge
---@param duration float
---@param completionHandler System.Action
---@return bool
function m:Hide(fade, edge, duration, completionHandler) end
---@param frame UnityEngine.Rect
---@param duration float
---@param delay float
---@param completionHandler System.Action
---@return bool
function m:AnimateTo(frame, duration, delay, completionHandler) end
---@param jsString string
---@param completionHandler System.Action
function m:AddJavaScript(jsString, completionHandler) end
---@param jsString string
---@param completionHandler System.Action
function m:EvaluateJavaScript(jsString, completionHandler) end
---@param scheme string
function m:AddUrlScheme(scheme) end
---@param scheme string
function m:RemoveUrlScheme(scheme) end
---@param domain string
function m:AddSslExceptionDomain(domain) end
---@param domain string
function m:RemoveSslExceptionDomain(domain) end
---@param key string
---@param value string
function m:SetHeaderField(key, value) end
---@param agent string
function m:SetUserAgent(agent) end
---@return string
function m:GetUserAgent() end
---@param flag bool
function m.SetAllowAutoPlay(flag) end
---@param flag bool
function m.SetAllowInlinePlay(flag) end
---@param enabled bool
function m.SetJavaScriptEnabled(enabled) end
---@param flag bool
function m.SetAllowJavaScriptOpenWindow(flag) end
function m:CleanCache() end
function m.ClearCookies() end
---@param url string
---@param cookie string
---@param skipEncoding bool
function m.SetCookie(url, cookie, skipEncoding) end
---@param url string
---@param key string
---@param skipEncoding bool
---@return string
function m.GetCookie(url, key, skipEncoding) end
---@param host string
---@param realm string
function m.ClearHttpAuthUsernamePassword(host, realm) end
---@param flag bool
function m:SetShowSpinnerWhileLoading(flag) end
---@param text string
function m:SetSpinnerText(text) end
---@param enabled bool
function m:SetHorizontalScrollBarEnabled(enabled) end
---@param enabled bool
function m:SetVerticalScrollBarEnabled(enabled) end
---@param enabled bool
function m:SetBouncesEnabled(enabled) end
---@param enabled bool
function m:SetZoomEnabled(enabled) end
---@param domain string
function m:AddPermissionTrustDomain(domain) end
---@param domain string
function m:RemovePermissionTrustDomain(domain) end
---@param enabled bool
function m:SetBackButtonEnabled(enabled) end
---@param flag bool
function m:SetUseWideViewPort(flag) end
---@param flag bool
function m:SetLoadWithOverviewMode(flag) end
---@param enabled bool
function m:SetImmersiveModeEnabled(enabled) end
---@param show bool
---@param animated bool
---@param onTop bool
---@param adjustInset bool
function m:SetShowToolbar(show, animated, onTop, adjustInset) end
---@param text string
function m:SetToolbarDoneButtonText(text) end
---@param enabled bool
function m.SetWebContentsDebuggingEnabled(enabled) end
---@param enabled bool
function m:SetWindowUserResizeEnabled(enabled) end
---@param handler System.Action
function m:GetHTMLContent(handler) end
function m:Print() end
UniWebView = m
return m