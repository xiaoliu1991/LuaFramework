---@class UnityEngine.AsyncOperation : object
---@field isDone bool
---@field progress float
---@field priority int
---@field allowSceneActivation bool
local m = {}
UnityEngine = {}
UnityEngine.AsyncOperation = m
return m