---@class UnityEngine.BoxCollider : UnityEngine.Collider
---@field center UnityEngine.Vector3
---@field size UnityEngine.Vector3
local m = {}
UnityEngine = {}
UnityEngine.BoxCollider = m
return m