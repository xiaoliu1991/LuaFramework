---@class UnityEngine.CameraClearFlags : System.Enum
---@field value__ int
---@field Skybox UnityEngine.CameraClearFlags
---@field Color UnityEngine.CameraClearFlags
---@field SolidColor UnityEngine.CameraClearFlags
---@field Depth UnityEngine.CameraClearFlags
---@field Nothing UnityEngine.CameraClearFlags
local m = {}
UnityEngine = {}
UnityEngine.CameraClearFlags = m
return m