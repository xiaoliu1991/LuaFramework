---@class UnityEngine.CapsuleCollider : UnityEngine.Collider
---@field center UnityEngine.Vector3
---@field radius float
---@field height float
---@field direction int
local m = {}
UnityEngine = {}
UnityEngine.CapsuleCollider = m
return m