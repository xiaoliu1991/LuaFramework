---@class UnityEngine.EventSystems.BaseEventData : UnityEngine.EventSystems.AbstractEventData
---@field currentInputModule UnityEngine.EventSystems.BaseInputModule
---@field selectedObject UnityEngine.GameObject
local m = {}
UnityEngine = {}
UnityEngine.EventSystems = {}
UnityEngine.EventSystems.BaseEventData = m
return m