---@class UnityEngine.Events.UnityEvent<Candlelight.UI.HyperText,Candlelight.UI.HyperText.LinkInfo> : UnityEngine.Events.UnityEventBase
local m = {}
---@param call UnityEngine.Events.UnityAction
function m:AddListener(call) end
---@param call UnityEngine.Events.UnityAction
function m:RemoveListener(call) end
---@param arg0 Candlelight.UI.HyperText
---@param arg1 Candlelight.UI.HyperText.LinkInfo
function m:Invoke(arg0, arg1) end
UnityEngine = {}
UnityEngine.Events = {}
UnityEngine.Events.UnityEvent<Candlelight = {}
UnityEngine.Events.UnityEvent<Candlelight.UI = {}
UnityEngine.Events.UnityEvent<Candlelight.UI.HyperText,Candlelight = {}
UnityEngine.Events.UnityEvent<Candlelight.UI.HyperText,Candlelight.UI = {}
UnityEngine.Events.UnityEvent<Candlelight.UI.HyperText,Candlelight.UI.HyperText = {}
UnityEngine.Events.UnityEvent<Candlelight.UI.HyperText,Candlelight.UI.HyperText.LinkInfo> = m
return m