---@class UnityEngine.FilterMode : System.Enum
---@field value__ int
---@field Point UnityEngine.FilterMode
---@field Bilinear UnityEngine.FilterMode
---@field Trilinear UnityEngine.FilterMode
local m = {}
UnityEngine = {}
UnityEngine.FilterMode = m
return m