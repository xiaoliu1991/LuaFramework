---@class UnityEngine.MeshRenderer : UnityEngine.Renderer
---@field additionalVertexStreams UnityEngine.Mesh
local m = {}
UnityEngine = {}
UnityEngine.MeshRenderer = m
return m