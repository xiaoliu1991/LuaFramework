---@class UnityEngine.PlayMode : System.Enum
---@field value__ int
---@field StopSameLayer UnityEngine.PlayMode
---@field StopAll UnityEngine.PlayMode
local m = {}
UnityEngine = {}
UnityEngine.PlayMode = m
return m