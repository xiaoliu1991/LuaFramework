---@class UnityEngine.QueueMode : System.Enum
---@field value__ int
---@field CompleteOthers UnityEngine.QueueMode
---@field PlayNow UnityEngine.QueueMode
local m = {}
UnityEngine = {}
UnityEngine.QueueMode = m
return m