---@class UnityEngine.RenderTextureFormat : System.Enum
---@field value__ int
---@field ARGB32 UnityEngine.RenderTextureFormat
---@field Depth UnityEngine.RenderTextureFormat
---@field ARGBHalf UnityEngine.RenderTextureFormat
---@field Shadowmap UnityEngine.RenderTextureFormat
---@field RGB565 UnityEngine.RenderTextureFormat
---@field ARGB4444 UnityEngine.RenderTextureFormat
---@field ARGB1555 UnityEngine.RenderTextureFormat
---@field Default UnityEngine.RenderTextureFormat
---@field ARGB2101010 UnityEngine.RenderTextureFormat
---@field DefaultHDR UnityEngine.RenderTextureFormat
---@field ARGB64 UnityEngine.RenderTextureFormat
---@field ARGBFloat UnityEngine.RenderTextureFormat
---@field RGFloat UnityEngine.RenderTextureFormat
---@field RGHalf UnityEngine.RenderTextureFormat
---@field RFloat UnityEngine.RenderTextureFormat
---@field RHalf UnityEngine.RenderTextureFormat
---@field R8 UnityEngine.RenderTextureFormat
---@field ARGBInt UnityEngine.RenderTextureFormat
---@field RGInt UnityEngine.RenderTextureFormat
---@field RInt UnityEngine.RenderTextureFormat
---@field BGRA32 UnityEngine.RenderTextureFormat
---@field RGB111110Float UnityEngine.RenderTextureFormat
---@field RG32 UnityEngine.RenderTextureFormat
---@field RGBAUShort UnityEngine.RenderTextureFormat
---@field RG16 UnityEngine.RenderTextureFormat
---@field BGRA10101010_XR UnityEngine.RenderTextureFormat
---@field BGR101010_XR UnityEngine.RenderTextureFormat
local m = {}
UnityEngine = {}
UnityEngine.RenderTextureFormat = m
return m