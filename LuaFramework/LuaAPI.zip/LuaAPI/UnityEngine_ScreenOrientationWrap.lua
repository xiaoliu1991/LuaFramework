---@class UnityEngine.ScreenOrientation : System.Enum
---@field value__ int
---@field Unknown UnityEngine.ScreenOrientation
---@field Portrait UnityEngine.ScreenOrientation
---@field PortraitUpsideDown UnityEngine.ScreenOrientation
---@field LandscapeLeft UnityEngine.ScreenOrientation
---@field LandscapeRight UnityEngine.ScreenOrientation
---@field AutoRotation UnityEngine.ScreenOrientation
---@field Landscape UnityEngine.ScreenOrientation
local m = {}
UnityEngine = {}
UnityEngine.ScreenOrientation = m
return m