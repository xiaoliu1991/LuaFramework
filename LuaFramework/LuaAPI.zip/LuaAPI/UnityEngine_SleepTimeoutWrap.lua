---@class UnityEngine.SleepTimeout : object
---@field NeverSleep int
---@field SystemSetting int
local m = {}
UnityEngine = {}
UnityEngine.SleepTimeout = m
return m