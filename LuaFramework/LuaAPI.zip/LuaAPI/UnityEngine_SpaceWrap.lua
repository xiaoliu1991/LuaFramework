---@class UnityEngine.Space : System.Enum
---@field value__ int
---@field World UnityEngine.Space
---@field Self UnityEngine.Space
local m = {}
UnityEngine = {}
UnityEngine.Space = m
return m