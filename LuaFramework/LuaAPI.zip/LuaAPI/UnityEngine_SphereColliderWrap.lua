---@class UnityEngine.SphereCollider : UnityEngine.Collider
---@field center UnityEngine.Vector3
---@field radius float
local m = {}
UnityEngine = {}
UnityEngine.SphereCollider = m
return m