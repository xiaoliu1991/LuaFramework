---@class UnityEngine.TextAsset : UnityEngine.Object
---@field text string
---@field bytes table
local m = {}
---@return string
function m:ToString() end
UnityEngine = {}
UnityEngine.TextAsset = m
return m