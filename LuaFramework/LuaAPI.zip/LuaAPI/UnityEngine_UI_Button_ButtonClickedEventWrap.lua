---@class UnityEngine.UI.Button.ButtonClickedEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.Button = {}
UnityEngine.UI.Button.ButtonClickedEvent = m
return m