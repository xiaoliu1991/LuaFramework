---@class UnityEngine.UI.HorizontalOrVerticalLayoutGroup : UnityEngine.UI.LayoutGroup
---@field spacing float
---@field childForceExpandWidth bool
---@field childForceExpandHeight bool
---@field childControlWidth bool
---@field childControlHeight bool
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.HorizontalOrVerticalLayoutGroup = m
return m