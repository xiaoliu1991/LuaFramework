---@class UnityEngine.UI.InputField.OnChangeEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.InputField = {}
UnityEngine.UI.InputField.OnChangeEvent = m
return m