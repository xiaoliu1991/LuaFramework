---@class UnityEngine.UI.InputField.SubmitEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.InputField = {}
UnityEngine.UI.InputField.SubmitEvent = m
return m