---@class UnityEngine.UI.LoopHorizontalScrollRect : UnityEngine.UI.LoopScrollRect
---@field prefabSource UnityEngine.UI.LoopScrollPrefabSource
---@field totalCount int
---@field dataSource UnityEngine.UI.LoopScrollDataSource
---@field threshold float
---@field reverseDirection bool
---@field rubberScale float
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.LoopHorizontalScrollRect = m
return m