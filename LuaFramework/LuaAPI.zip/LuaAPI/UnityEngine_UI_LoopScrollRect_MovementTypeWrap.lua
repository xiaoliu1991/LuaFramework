---@class UnityEngine.UI.LoopScrollRect.MovementType : System.Enum
---@field value__ int
---@field Unrestricted UnityEngine.UI.LoopScrollRect.MovementType
---@field Elastic UnityEngine.UI.LoopScrollRect.MovementType
---@field Clamped UnityEngine.UI.LoopScrollRect.MovementType
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.LoopScrollRect = {}
UnityEngine.UI.LoopScrollRect.MovementType = m
return m