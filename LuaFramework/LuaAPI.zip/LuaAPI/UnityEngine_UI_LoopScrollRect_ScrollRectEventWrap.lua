---@class UnityEngine.UI.LoopScrollRect.ScrollRectEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.LoopScrollRect = {}
UnityEngine.UI.LoopScrollRect.ScrollRectEvent = m
return m