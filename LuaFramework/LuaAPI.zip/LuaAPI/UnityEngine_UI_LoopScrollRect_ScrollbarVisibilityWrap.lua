---@class UnityEngine.UI.LoopScrollRect.ScrollbarVisibility : System.Enum
---@field value__ int
---@field Permanent UnityEngine.UI.LoopScrollRect.ScrollbarVisibility
---@field AutoHide UnityEngine.UI.LoopScrollRect.ScrollbarVisibility
---@field AutoHideAndExpandViewport UnityEngine.UI.LoopScrollRect.ScrollbarVisibility
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.LoopScrollRect = {}
UnityEngine.UI.LoopScrollRect.ScrollbarVisibility = m
return m