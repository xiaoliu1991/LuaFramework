---@class UnityEngine.UI.LoopVerticalScrollRect : UnityEngine.UI.LoopScrollRect
---@field prefabSource UnityEngine.UI.LoopScrollPrefabSource
---@field totalCount int
---@field dataSource UnityEngine.UI.LoopScrollDataSource
---@field threshold float
---@field reverseDirection bool
---@field rubberScale float
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.LoopVerticalScrollRect = m
return m