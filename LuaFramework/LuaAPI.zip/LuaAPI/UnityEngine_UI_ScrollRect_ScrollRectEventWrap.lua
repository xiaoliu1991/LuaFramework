---@class UnityEngine.UI.ScrollRect.ScrollRectEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.ScrollRect = {}
UnityEngine.UI.ScrollRect.ScrollRectEvent = m
return m