---@class UnityEngine.UI.Scrollbar : UnityEngine.UI.Selectable
---@field handleRect UnityEngine.RectTransform
---@field direction UnityEngine.UI.Scrollbar.Direction
---@field value float
---@field size float
---@field numberOfSteps int
---@field onValueChanged UnityEngine.UI.Scrollbar.ScrollEvent
local m = {}
---@param executing UnityEngine.UI.CanvasUpdate
function m:Rebuild(executing) end
function m:LayoutComplete() end
function m:GraphicUpdateComplete() end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnBeginDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end
---@param eventData UnityEngine.EventSystems.AxisEventData
function m:OnMove(eventData) end
---@return UnityEngine.UI.Selectable
function m:FindSelectableOnLeft() end
---@return UnityEngine.UI.Selectable
function m:FindSelectableOnRight() end
---@return UnityEngine.UI.Selectable
function m:FindSelectableOnUp() end
---@return UnityEngine.UI.Selectable
function m:FindSelectableOnDown() end
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnInitializePotentialDrag(eventData) end
---@param direction UnityEngine.UI.Scrollbar.Direction
---@param includeRectLayouts bool
function m:SetDirection(direction, includeRectLayouts) end
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.Scrollbar = m
return m