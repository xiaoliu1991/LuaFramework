---@class UnityEngine.UI.Scrollbar.ScrollEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.Scrollbar = {}
UnityEngine.UI.Scrollbar.ScrollEvent = m
return m