---@class UnityEngine.UI.Slider.SliderEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.Slider = {}
UnityEngine.UI.Slider.SliderEvent = m
return m