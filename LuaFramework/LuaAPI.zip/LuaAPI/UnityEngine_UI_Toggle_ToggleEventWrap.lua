---@class UnityEngine.UI.Toggle.ToggleEvent : UnityEngine.Events.UnityEvent
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.Toggle = {}
UnityEngine.UI.Toggle.ToggleEvent = m
return m