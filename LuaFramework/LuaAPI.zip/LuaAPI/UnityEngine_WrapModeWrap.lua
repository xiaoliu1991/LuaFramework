---@class UnityEngine.WrapMode : System.Enum
---@field value__ int
---@field Once UnityEngine.WrapMode
---@field Loop UnityEngine.WrapMode
---@field PingPong UnityEngine.WrapMode
---@field Default UnityEngine.WrapMode
---@field ClampForever UnityEngine.WrapMode
---@field Clamp UnityEngine.WrapMode
local m = {}
UnityEngine = {}
UnityEngine.WrapMode = m
return m