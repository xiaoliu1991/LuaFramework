---@class WebManager : GameCore.UnitySingleton
local m = {}
---@param input string
---@return string
function m.Base64Encode(input) end
---@param input string
---@return string
function m.Base64Decode(input) end
---@param urlStr string
---@return string
function m.EncodeUrlString(urlStr) end
---@param stringToEscape string
---@return string
function m.EscapeString(stringToEscape) end
---@param stringToUnescape string
---@return string
function m.UnescapeString(stringToUnescape) end
function m.StopAllWWWCoroutine() end
---@overload fun(url:string, co:UnityEngine.Coroutine):void
---@param url string
function m.StopWWWCoroutine(url) end
---@param url string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestText(url, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param postBytes table
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestTextByPostBytes(url, postBytes, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param jsonData string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestTextByPostJson(url, jsonData, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param texture2D UnityEngine.Texture2D
---@param field string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestTextByPostFormWithBytes(url, texture2D, field, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param form UnityEngine.WWWForm
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestTextByPostForm(url, form, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param postDatas string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestTextByPostStrForm(url, postDatas, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestTexture(url, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestAudio(url, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestAssetBundle(url, secuessHandle, failHandle, timeOut, data) end
---@param url string
---@param secuessHandle GameLogic.GameEventHandler
---@param failHandle GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.RequestBytes(url, secuessHandle, failHandle, timeOut, data) end
---@param picName string
---@param storagePath string
---@param uploadUrl string
---@param rect UnityEngine.Rect
---@param info string
---@param secuessScreenShot GameLogic.GameEventHandler
---@param failScreenShot GameLogic.GameEventHandler
---@param secuessUpload GameLogic.GameEventHandler
---@param failUpload GameLogic.GameEventHandler
---@param timeOut int
---@param data table
function m.UploadScreenShot(picName, storagePath, uploadUrl, rect, info, secuessScreenShot, failScreenShot, secuessUpload, failUpload, timeOut, data) end
WebManager = m
return m